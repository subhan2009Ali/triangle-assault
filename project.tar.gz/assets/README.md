# Triangle Assault

A polished, top-down arcade space shooter built with **Python 3** and **[pygame-ce](https://pyga.me/)**.
Fly a triangle ship, blast infinite waves of enemies, level up, loot power-ups, spend
coins in the between-wave upgrade shop, and survive escalating multi-phase boss fights.

Art and sound are from Kenney.nl's **Space Shooter Extension**, **Digital Audio**, and
**Sci-Fi Sounds** packs (CC0 — free for any use).

---

## Requirements

- Python 3.10+ (developed/tested on 3.12)
- [pygame-ce](https://pypi.org/project/pygame-ce/) 2.5+

```bash
pip install -r requirements.txt
```

> **Note:** this project uses `pygame-ce` (the community fork of pygame), not the
> original `pygame` package. If you have vanilla `pygame` installed, uninstall it
> first (`pip uninstall pygame`) to avoid an import conflict, then install
> `pygame-ce`.

## Running the game

```bash
python main.py
```

Settings and meta-progression (high score, coins, permanent upgrades, unlocked
weapons) are saved to `saves/savegame.json` automatically and reloaded on next
launch. Delete that file at any time to reset progress.

---

## Controls

| Action          | Input                                        |
|-----------------|-----------------------------------------------|
| Move            | Move the mouse — the ship eases toward the cursor with inertia |
| Aim             | Automatic — the ship always faces the cursor  |
| Fire            | Hold **Left Mouse Button**                    |
| Switch weapon   | **Q** / **E**                                  |
| Pause           | **Esc**                                        |
| Mute            | **M**                                          |

---

## Features

- **Inertial mouse-follow flight** — smooth acceleration/deceleration, not
  instant snapping; the ship always banks to face the cursor.
- **5 weapons** (Machine Gun, Spread Shot, Shotgun, Laser, Missile Launcher),
  each with its own fire pattern, and a per-weapon level that scales damage
  and fire rate as you use it.
- **11 enemy archetypes** (Scout, Interceptor, Bulwark, Gunship, Marksman,
  Detonator, Ravager, Aegis, Medic Drone, Elite Warden, Asteroid) with
  distinct AI: chase, keep-range-and-shoot, snipe, kamikaze-charge, shield
  cycling, and ally-healing.
- **Multi-phase boss fights** every 5 waves — spread barrages, a rotating
  laser sweep, a charge attack, a shockwave burst, minion summons, a
  temporary shield phase, and a permanent enrage state under 30% HP.
  Smaller "mini-boss" variants use the same system with a trimmed attack
  pool.
- **Infinite scaling waves** — enemy count, spawn rate, and enemy stats all
  grow every wave; difficulty setting (easy/normal/hard/insane) further
  scales enemy health/damage/spawn-rate.
- **15 power-ups** (health, shield, rapid fire, double damage, triple shot,
  homing, speed boost, slow-motion, magnet, freeze, bomb, invincibility,
  extra life, coin multiplier, regen), each with its own icon color, pickup
  sound, timer, and expiration.
- **Coins, XP/leveling, and a permanent upgrade shop** between waves — spend
  coins on 10 stacking upgrade tracks (max health, damage, move speed,
  reload speed, crit chance, shield capacity, energy regen, luck, XP gain,
  coin gain) or unlock new weapons permanently.
- **Juice**: camera shake, screen flash on damage, floating damage/heal
  numbers, particle explosions/sparks/trails, animated health bars, hit
  flashes, weapon glow, parallax starfield.
- **Full menu flow**: Main Menu, Settings (video/audio/gameplay), Controls,
  Credits, Pause, Shop, Game Over — all sharing one small UI toolkit
  (`systems/ui.py`) for a consistent look.
- **Settings**: fullscreen/windowed, music/SFX volume sliders, mute,
  difficulty, screen-shake toggle, damage-number toggle, FPS counter toggle.
- **JSON save system** for high score, total coins, unlocked weapons,
  permanent upgrade levels, and settings.
- **Centralized AssetManager** — every image/sound is requested by a
  logical key, never a hardcoded path; missing assets fall back to a
  clearly-marked placeholder instead of crashing.

---

## Project Structure

```
project/
│
├── main.py                  # Entry point / main loop
├── config.py                 # Player-editable runtime settings (Config dataclass)
├── constants.py               # Static tuning values, colors, enums
│
├── assets/
│   ├── images/{ships,meteors,effects,missiles}/   # Kenney Space Shooter Extension art
│   ├── sounds/                                     # Kenney Digital Audio + Sci-Fi Sounds
│   └── fonts/                                      # (optional custom .ttf/.otf go here)
│
├── entities/
│   ├── player.py             # Player ship: movement, health/shield, status effects
│   ├── weapon.py              # Weapon definitions + fire patterns
│   ├── bullet.py               # Bullet/projectile + BulletManager
│   ├── enemy.py                # Enemy definitions + AI archetypes
│   ├── boss.py                  # Multi-phase boss state machine
│   └── powerup.py                # Power-up definitions + drop table
│
├── systems/
│   ├── collision.py           # Circle-collision resolution
│   ├── particles.py            # Particle + floating-text VFX system
│   ├── camera.py                # Screen shake + flash
│   ├── sound.py                  # SFX/music playback wrapper
│   ├── wave_manager.py            # Wave/spawn/boss-timing state machine
│   ├── upgrade_shop.py             # Permanent upgrade costs/purchase logic
│   ├── ui.py                        # Shared buttons/sliders/bars/panels
│   └── save_system.py                # JSON save/load
│
├── scenes/
│   ├── base.py                # Scene + SceneManager (stack-based)
│   ├── menu.py                 # Main menu
│   ├── gameplay.py              # Core play loop
│   ├── shop.py                   # Between-wave upgrade shop
│   ├── pause.py                   # Pause overlay
│   ├── game_over.py                # Game over / run summary
│   ├── settings.py                  # Settings screen
│   ├── controls.py                   # Controls reference
│   └── credits.py                     # Credits
│
├── utils/
│   ├── math_utils.py           # Vector/angle/interpolation helpers
│   ├── asset_loader.py          # Centralized AssetManager
│   └── timer.py                   # Reusable countdown timer
│
├── saves/
│   └── savegame.json            # Created automatically on first run
│
├── requirements.txt
├── config.example.json          # Example shape of the save/settings file
└── README.md
```

---

## How to Add New Content

The project is deliberately structured so new content is additive — you
add one data entry, not new code paths, in almost every case.

### Add a new enemy type

1. Add a value to `EnemyType` in `constants.py`.
2. Add an `EnemyDef(...)` entry to `ENEMY_DEFS` in `entities/enemy.py` with
   its stats and an `ai` string (`"chase"`, `"shooter"`, `"sniper"`,
   `"kamikaze"`, `"exploder"`, `"shield"`, `"healer"`, or `"drift"`).
3. Add it to the weighted pool in `pick_enemy_type()` (same file) at the
   wave number you want it to start appearing.
4. If it needs genuinely new behavior, add one `elif ai == "..."` branch in
   `Enemy.update()`.

### Add a new weapon

1. Add a value to `WeaponType` in `constants.py`.
2. Add a `WeaponStats(...)` entry to `WEAPON_DEFS` in `entities/weapon.py`.
3. (Optional) add it to `WEAPON_UNLOCK_COSTS` in `systems/upgrade_shop.py`
   so it's purchasable in the shop, and to `WEAPON_UNLOCK_ORDER` in
   `scenes/gameplay.py` so it can drop as a pickup.

### Add a new power-up

1. Add a value to `PowerUpType` in `constants.py`.
2. Add a `PowerUpDef(...)` entry to `POWERUP_DEFS` in `entities/powerup.py`.
3. Handle its effect in `GameplayScene._apply_powerup()` in
   `scenes/gameplay.py` (usually one line starting a `Timer` on
   `player.status`).

### Add new sounds

Drop a `.ogg` or `.wav` file anywhere under `assets/sounds/` — no code
changes needed elsewhere. Reference it by filename stem (no extension,
case-insensitive) anywhere a `sound_keys` tuple or `ctx.sound.play(...)`
call is made, e.g. `ctx.sound.play("my_new_sound")`.

### Add new sprites

Drop a `.png`/`.jpg` anywhere under `assets/images/` and reference it by
filename stem via `assets.get_image("my_sprite", (w, h))`. If the key isn't
found, a magenta/black checker placeholder is used instead of crashing, so
you can wire up gameplay before final art is ready.

### Add a new boss attack

Add a new `BossPhase` enum value in `entities/boss.py`, add it to
`Boss.attack_pool`, add a duration to the `durations` dict in
`_pick_next_phase()`, and add an `elif self.phase == BossPhase.YOUR_PHASE:`
block in `Boss.update()`.

---

## Playing on a phone

This sandbox's tool environment couldn't finish either mobile build
itself (both need to download large toolchains from servers outside
its network allowlist), but the project is fully set up for you to
finish either one in a couple of minutes, with no local Android/build
experience needed.

### Option A -- Web build (recommended: fastest, most reliable)

pygame-ce's own team maintains [pygbag](https://github.com/pygame-web/pygbag),
which compiles this exact code to WebAssembly and runs it in any mobile
browser -- no install, no app store, and touch works automatically
because pygame's touch-to-mouse translation means "drag to move / hold
to fire" just works as-is. `main.py` is already written in the
async-loop shape pygbag requires, so no code changes are needed.

On a computer with normal internet access:

```bash
pip install pygbag
cd project
pygbag main.py
```

It prints a `localhost` URL -- open that on your computer to test. To
actually play on your phone, host the generated `build/web` folder
somewhere public and open it in your phone's browser:

- **Quickest:** drag the `build/web` folder onto [itch.io](https://itch.io) as an HTML5 project (free, a few clicks).
- **Or:** push `build/web` to a GitHub repo and enable GitHub Pages on it.

Once it's open in Chrome/Safari on your phone, use "Add to Home
Screen" for an app-like icon and full-screen launch.

### Option B -- Real installable APK (via GitHub Actions)

This repo already includes `buildozer.spec` and
`.github/workflows/build-apk.yml`, which builds a genuine Android
`.apk` automatically using GitHub's own servers (which have the
internet access this sandbox didn't):

1. Push this whole `project/` folder to a new GitHub repository.
2. Open the repo's **Actions** tab -> **Build Android APK** -> **Run workflow**.
3. Wait for it to finish (~15-25 minutes the first run). Open the
   completed run and download the **triangle-assault-apk** artifact --
   that's a zip containing the `.apk`.
4. Copy the `.apk` to your phone and open it to install (Android will
   ask you to allow installing from this source once).

Buildozer/python-for-android builds can occasionally need small
tweaks for a given pygame-ce version -- if the Action fails, the log
in the Actions tab will show exactly which step to fix.

---

## Building an Executable

Using [PyInstaller](https://pyinstaller.org/):

```bash
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed \
    --add-data "assets:assets" \
    --name "TriangleAssault" main.py
```

The `--add-data` flag bundles the `assets/` folder into the executable
(on Windows, use `--add-data "assets;assets"` — semicolon instead of colon).
The finished executable will be in `dist/`.

---

## Credits

- **Engine:** [pygame-ce](https://pyga.me/) — a community-maintained fork of pygame.
- **Art:** Kenney "Space Shooter Extension" pack — [kenney.nl](https://kenney.nl)
- **Sound:** Kenney "Digital Audio" and "Sci-Fi Sounds" packs — [kenney.nl](https://kenney.nl)

All Kenney assets are released under [CC0](https://creativecommons.org/publicdomain/zero/1.0/) (public domain).
