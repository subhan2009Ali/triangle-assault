"""
constants.py
------------
Static, never-changes-at-runtime values: screen defaults, colors,
physics tuning, gameplay tuning, layer/z-order constants, enums.

Anything the *player* can change (volume, resolution, key bindings)
belongs in config.py / the save file instead of here.
"""
from __future__ import annotations

from enum import Enum, auto

# --------------------------------------------------------------------------
# Display
# --------------------------------------------------------------------------
DEFAULT_SCREEN_WIDTH = 1280
DEFAULT_SCREEN_HEIGHT = 720
FPS_CAP = 144
GAME_TITLE = "TRIANGLE ASSAULT"

# --------------------------------------------------------------------------
# Colors (R, G, B)
# --------------------------------------------------------------------------
class Color:
    BLACK = (8, 9, 14)
    WHITE = (240, 244, 250)
    BG_TOP = (6, 8, 18)
    BG_BOTTOM = (14, 12, 28)

    NEON_CYAN = (68, 220, 235)
    NEON_MAGENTA = (235, 68, 190)
    NEON_PURPLE = (150, 90, 240)
    NEON_GREEN = (100, 240, 130)
    NEON_YELLOW = (245, 210, 70)
    NEON_ORANGE = (250, 140, 60)
    NEON_RED = (245, 70, 80)
    NEON_BLUE = (80, 150, 245)

    HEALTH = (90, 230, 120)
    HEALTH_LOW = (240, 70, 70)
    SHIELD = (90, 180, 245)
    ARMOR = (200, 200, 210)
    XP = (190, 120, 245)
    COIN = (250, 210, 90)

    UI_BG = (18, 20, 32, 210)
    UI_BORDER = (90, 200, 230, 180)
    UI_DIM = (150, 160, 180)

    PANEL = (22, 24, 38)
    PANEL_LIGHT = (34, 38, 56)


# --------------------------------------------------------------------------
# Layers (draw order, low -> high)
# --------------------------------------------------------------------------
class Layer(Enum):
    BACKGROUND = 0
    STARFIELD = 1
    PICKUP = 2
    PARTICLE_BEHIND = 3
    ENEMY = 4
    PLAYER = 5
    BULLET = 6
    PARTICLE_FRONT = 7
    UI_WORLD = 8


# --------------------------------------------------------------------------
# Physics / feel tuning
# --------------------------------------------------------------------------
PLAYER_MAX_SPEED = 420.0
PLAYER_ACCELERATION = 2200.0
PLAYER_DRAG = 6.0
PLAYER_ROTATION_SMOOTH = 14.0
PLAYER_RADIUS = 26

WORLD_MARGIN = 40  # keep player inside screen bounds with a small margin

# --------------------------------------------------------------------------
# Gameplay tuning
# --------------------------------------------------------------------------
PLAYER_BASE_HEALTH = 100
PLAYER_BASE_ARMOR = 0
PLAYER_BASE_LIVES = 3
PLAYER_IFRAME_DURATION = 1.1
PLAYER_BASE_SHIELD = 0
PLAYER_HIT_FLASH_DURATION = 0.15

XP_PER_LEVEL_BASE = 60
XP_PER_LEVEL_GROWTH = 1.18

WAVE_INTERMISSION_TIME = 6.0
BOSS_EVERY_N_WAVES = 5
WAVE_ENEMY_BASE_COUNT = 6
WAVE_ENEMY_GROWTH = 1.16
WAVE_SPAWN_INTERVAL_BASE = 1.1
WAVE_SPAWN_INTERVAL_MIN = 0.18

CAMERA_SHAKE_DECAY = 6.0

# --------------------------------------------------------------------------
# Enums
# --------------------------------------------------------------------------
class GameState(Enum):
    MAIN_MENU = auto()
    SETTINGS = auto()
    CONTROLS = auto()
    CREDITS = auto()
    GAMEPLAY = auto()
    PAUSED = auto()
    SHOP = auto()
    GAME_OVER = auto()


class EnemyType(Enum):
    SMALL = auto()
    FAST = auto()
    TANK = auto()
    SHOOTER = auto()
    SNIPER = auto()
    EXPLODER = auto()
    KAMIKAZE = auto()
    SHIELD = auto()
    HEALER = auto()
    ELITE = auto()
    ASTEROID = auto()
    MINI_BOSS = auto()
    BOSS = auto()


class WeaponType(Enum):
    MACHINE_GUN = auto()
    SPREAD = auto()
    SHOTGUN = auto()
    LASER = auto()
    MISSILE = auto()


class PowerUpType(Enum):
    HEALTH = auto()
    SHIELD_BOOST = auto()
    RAPID_FIRE = auto()
    DOUBLE_DAMAGE = auto()
    TRIPLE_SHOT = auto()
    HOMING = auto()
    SPEED_BOOST = auto()
    SLOW_MOTION = auto()
    MAGNET = auto()
    FREEZE = auto()
    BOMB = auto()
    INVINCIBILITY = auto()
    EXTRA_LIFE = auto()
    COIN_MULTIPLIER = auto()
    REGEN = auto()


class SpawnEdge(Enum):
    TOP = auto()
    BOTTOM = auto()
    LEFT = auto()
    RIGHT = auto()
    TOP_LEFT = auto()
    TOP_RIGHT = auto()
    BOTTOM_LEFT = auto()
    BOTTOM_RIGHT = auto()
