"""
systems/camera.py
------------------
The world is small enough that we don't need scrolling, but a Camera
object still earns its place: it owns screen-shake offset and the
"flash" overlay, so any system can trigger juice (`camera.shake(...)`)
without reaching into the render loop directly.
"""
from __future__ import annotations

import random

import pygame

from constants import Color
from utils.math_utils import clamp
from constants import CAMERA_SHAKE_DECAY


class Camera:
    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        self.trauma = 0.0  # 0..1, decays over time; shake magnitude = trauma^2
        self.offset = pygame.Vector2(0, 0)
        self.flash_alpha = 0.0
        self.flash_color = Color.NEON_RED
        self._flash_surface = pygame.Surface((width, height), pygame.SRCALPHA)

    def resize(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        self._flash_surface = pygame.Surface((width, height), pygame.SRCALPHA)

    def shake(self, amount: float) -> None:
        self.trauma = clamp(self.trauma + amount, 0.0, 1.0)

    def flash(self, color=Color.NEON_RED, alpha: float = 140) -> None:
        self.flash_color = color
        self.flash_alpha = alpha

    def update(self, dt: float, shake_enabled: bool = True) -> None:
        if self.trauma > 0:
            self.trauma = clamp(self.trauma - CAMERA_SHAKE_DECAY * dt, 0.0, 1.0)
        if shake_enabled and self.trauma > 0:
            power = self.trauma ** 2
            max_offset = 18 * power
            self.offset.x = random.uniform(-1, 1) * max_offset
            self.offset.y = random.uniform(-1, 1) * max_offset
        else:
            self.offset.update(0, 0)

        if self.flash_alpha > 0:
            self.flash_alpha = max(0.0, self.flash_alpha - dt * 420)

    def draw_flash(self, surface: pygame.Surface) -> None:
        if self.flash_alpha <= 0:
            return
        self._flash_surface.fill((*self.flash_color, int(self.flash_alpha)))
        surface.blit(self._flash_surface, (0, 0))
