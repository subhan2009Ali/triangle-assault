"""
systems/sound.py
-----------------
SoundManager centralizes every audio call in the game: SFX playback
(with per-category volume and simple randomized-pitch-free variety via
picking from a list of clip names), and streamed music.

Nothing outside this file should ever touch pygame.mixer directly.
"""
from __future__ import annotations

import random
from typing import Iterable, Optional

import pygame

from utils.asset_loader import assets


class SoundManager:
    def __init__(self, config) -> None:
        self.config = config
        self._channel_pool: list[pygame.mixer.Channel] = []
        self._current_music_key: Optional[str] = None
        try:
            pygame.mixer.set_num_channels(32)
            self._channel_pool = [pygame.mixer.Channel(i) for i in range(8, 32)]
        except pygame.error:
            self._channel_pool = []

    # -- volume ---------------------------------------------------------
    @property
    def sfx_volume(self) -> float:
        return 0.0 if self.config.muted else self.config.sfx_volume

    @property
    def music_volume(self) -> float:
        return 0.0 if self.config.muted else self.config.music_volume

    def refresh_music_volume(self) -> None:
        if pygame.mixer.get_init():
            pygame.mixer.music.set_volume(self.music_volume)

    # -- sfx --------------------------------------------------------------
    def play(self, key: str | Iterable[str], volume: float = 1.0, pitch_variety: bool = False) -> None:
        """Play a sound effect. `key` may be a single logical name or an
        iterable of candidate names, one of which is chosen at random
        (handy for e.g. laser1..laser9 variety)."""
        if not pygame.mixer.get_init():
            return
        if isinstance(key, str):
            chosen = key
        else:
            chosen = random.choice(list(key))

        sound = assets.get_sound(chosen)
        if sound is None:
            return
        sound.set_volume(clamp01(volume) * self.sfx_volume)
        channel = self._get_free_channel()
        if channel:
            channel.play(sound)
        else:
            sound.play()

    def _get_free_channel(self) -> Optional[pygame.mixer.Channel]:
        for ch in self._channel_pool:
            if not ch.get_busy():
                return ch
        return None

    # -- music --------------------------------------------------------
    def play_music(self, key: str, loop: bool = True) -> None:
        if not pygame.mixer.get_init():
            return
        path = assets.get_music_path(key)
        if not path or self._current_music_key == key:
            return
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(self.music_volume)
            pygame.mixer.music.play(-1 if loop else 0)
            self._current_music_key = key
        except pygame.error:
            pass

    def stop_music(self, fade_ms: int = 400) -> None:
        if pygame.mixer.get_init():
            pygame.mixer.music.fadeout(fade_ms)
        self._current_music_key = None

    def toggle_mute(self) -> None:
        self.config.muted = not self.config.muted
        self.refresh_music_volume()


def clamp01(v: float) -> float:
    return max(0.0, min(1.0, v))
