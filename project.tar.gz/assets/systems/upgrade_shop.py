"""
systems/upgrade_shop.py
------------------------
Between-wave shop: spend coins on permanent, run-persistent upgrades
(stored in SaveData.upgrades) plus one-off in-run heals/weapon
unlocks. Costs scale per-level so early upgrades are cheap and later
ones meaningfully expensive.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from constants import WeaponType
from systems.save_system import UpgradeLevels

MAX_UPGRADE_LEVEL = 10


@dataclass
class UpgradeOption:
    key: str
    label: str
    description: str
    base_cost: int
    cost_growth: float = 1.35


UPGRADE_OPTIONS: list[UpgradeOption] = [
    UpgradeOption("max_health", "Max Health", "+12 max HP per level", 40),
    UpgradeOption("damage", "Damage", "+6% weapon damage per level", 50),
    UpgradeOption("move_speed", "Move Speed", "+18 max speed per level", 35),
    UpgradeOption("reload_speed", "Reload Speed", "Faster weapon cooldowns", 45),
    UpgradeOption("crit_chance", "Crit Chance", "+2% crit chance per level", 55),
    UpgradeOption("shield_capacity", "Shield Capacity", "+15 max shield per level", 50),
    UpgradeOption("energy_regen", "Energy Regen", "Passive shield regeneration", 45),
    UpgradeOption("luck", "Luck", "+1% power-up drop chance per level", 40),
    UpgradeOption("xp_gain", "XP Gain", "+8% XP earned per level", 35),
    UpgradeOption("coin_multiplier", "Coin Gain", "+8% coins earned per level", 35),
]

WEAPON_UNLOCK_COSTS = {
    WeaponType.SPREAD: 120,
    WeaponType.SHOTGUN: 160,
    WeaponType.LASER: 220,
    WeaponType.MISSILE: 300,
}


def upgrade_cost(option: UpgradeOption, current_level: int) -> int:
    return int(option.base_cost * (option.cost_growth ** current_level))


def can_afford(coins: int, cost: int) -> bool:
    return coins >= cost


def purchase_upgrade(upgrades: UpgradeLevels, option_key: str, coins: int) -> tuple[UpgradeLevels, int, bool]:
    """Returns (updated upgrades, remaining coins, success)."""
    option = next((o for o in UPGRADE_OPTIONS if o.key == option_key), None)
    if option is None:
        return upgrades, coins, False
    current_level = getattr(upgrades, option_key, 0)
    if current_level >= MAX_UPGRADE_LEVEL:
        return upgrades, coins, False
    cost = upgrade_cost(option, current_level)
    if coins < cost:
        return upgrades, coins, False
    setattr(upgrades, option_key, current_level + 1)
    return upgrades, coins - cost, True


def purchase_weapon(unlocked: list[str], weapon_type: WeaponType, coins: int) -> tuple[list[str], int, bool]:
    if weapon_type.name in unlocked:
        return unlocked, coins, False
    cost = WEAPON_UNLOCK_COSTS.get(weapon_type, 999999)
    if coins < cost:
        return unlocked, coins, False
    unlocked = list(unlocked) + [weapon_type.name]
    return unlocked, coins - cost, True
