"""
systems/save_system.py
-----------------------
Handles persistence of settings + meta-progression to a JSON file on
disk. Kept deliberately simple and defensive: any read/parse failure
falls back to sane defaults rather than crashing the game.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from typing import Any

from config import Config

SAVE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "saves")
SAVE_PATH = os.path.normpath(os.path.join(SAVE_DIR, "savegame.json"))

DEFAULT_UNLOCKED_WEAPONS = ["MACHINE_GUN"]


@dataclass
class UpgradeLevels:
    max_health: int = 0
    damage: int = 0
    move_speed: int = 0
    reload_speed: int = 0
    crit_chance: int = 0
    shield_capacity: int = 0
    energy_regen: int = 0
    luck: int = 0
    xp_gain: int = 0
    coin_multiplier: int = 0


@dataclass
class SaveData:
    high_score: int = 0
    total_coins: int = 0
    unlocked_weapons: list[str] = field(default_factory=lambda: list(DEFAULT_UNLOCKED_WEAPONS))
    unlocked_characters: list[str] = field(default_factory=lambda: ["default"])
    upgrades: UpgradeLevels = field(default_factory=UpgradeLevels)
    config: Config = field(default_factory=Config)
    waves_survived_best: int = 0

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "SaveData":
        save = SaveData()
        save.high_score = data.get("high_score", 0)
        save.total_coins = data.get("total_coins", 0)
        save.unlocked_weapons = data.get("unlocked_weapons", list(DEFAULT_UNLOCKED_WEAPONS))
        save.unlocked_characters = data.get("unlocked_characters", ["default"])
        save.waves_survived_best = data.get("waves_survived_best", 0)
        if "upgrades" in data:
            save.upgrades = UpgradeLevels(**data["upgrades"])
        if "config" in data:
            save.config = Config.from_dict(dict(data["config"]))
        return save


def load_game() -> SaveData:
    if not os.path.isfile(SAVE_PATH):
        return SaveData()
    try:
        with open(SAVE_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
        return SaveData.from_dict(raw)
    except (json.JSONDecodeError, OSError, TypeError, KeyError):
        return SaveData()


def save_game(data: SaveData) -> None:
    os.makedirs(SAVE_DIR, exist_ok=True)
    try:
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            json.dump(data.to_dict(), f, indent=2)
    except OSError:
        pass
