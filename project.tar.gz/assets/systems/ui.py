"""
systems/ui.py
--------------
Shared UI drawing primitives (panels, bars, buttons, sliders) used by
every scene, so the HUD, menus and shop all share one visual language
instead of each scene reinventing text rendering.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

import pygame

from constants import Color
from utils.asset_loader import assets
from utils.math_utils import clamp, ease_out_cubic

_font_cache: dict[tuple[int, bool], pygame.font.Font] = {}


def font(size: int, bold: bool = True) -> pygame.font.Font:
    key = (size, bold)
    if key not in _font_cache:
        f = assets.get_font(size) if assets else pygame.font.SysFont("arial,helvetica", size, bold=bold)
        f.set_bold(bold)
        _font_cache[key] = f
    return _font_cache[key]


def draw_text(
    surface: pygame.Surface,
    text: str,
    pos,
    size: int = 22,
    color=Color.WHITE,
    bold: bool = True,
    align: str = "topleft",
    shadow: bool = True,
    alpha: int = 255,
) -> pygame.Rect:
    f = font(size, bold)
    surf = f.render(text, True, color)
    if alpha < 255:
        surf.set_alpha(alpha)
    rect = surf.get_rect(**{align: pos})
    if shadow:
        shadow_surf = f.render(text, True, (0, 0, 0))
        shadow_surf.set_alpha(min(140, alpha))
        surface.blit(shadow_surf, rect.move(2, 2))
    surface.blit(surf, rect)
    return rect


def draw_panel(surface: pygame.Surface, rect: pygame.Rect, color=Color.PANEL, border_color=Color.UI_BORDER, radius: int = 12, alpha: int = 210, border_width: int = 2) -> None:
    panel = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(panel, (*color[:3], alpha), panel.get_rect(), border_radius=radius)
    if border_width > 0:
        pygame.draw.rect(panel, border_color, panel.get_rect(), border_width, border_radius=radius)
    surface.blit(panel, rect.topleft)


def draw_bar(
    surface: pygame.Surface,
    rect: pygame.Rect,
    ratio: float,
    fill_color,
    bg_color=(30, 30, 40),
    border_color=(0, 0, 0),
    radius: int = 6,
    glow: bool = False,
) -> None:
    ratio = clamp(ratio, 0.0, 1.0)
    pygame.draw.rect(surface, bg_color, rect, border_radius=radius)
    if ratio > 0:
        fill_rect = pygame.Rect(rect.x, rect.y, int(rect.width * ratio), rect.height)
        pygame.draw.rect(surface, fill_color, fill_rect, border_radius=radius)
        if glow:
            glow_surf = pygame.Surface((fill_rect.width, fill_rect.height), pygame.SRCALPHA)
            pygame.draw.rect(glow_surf, (*fill_color[:3], 90), glow_surf.get_rect(), border_radius=radius)
            surface.blit(glow_surf, (fill_rect.x, fill_rect.y - 2))
    pygame.draw.rect(surface, border_color, rect, 2, border_radius=radius)


@dataclass
class Button:
    rect: pygame.Rect
    label: str
    callback: Optional[Callable] = None
    enabled: bool = True
    hovered: bool = False
    hover_t: float = 0.0
    subtitle: str = ""

    def update(self, dt: float, mouse_pos) -> None:
        self.hovered = self.enabled and self.rect.collidepoint(mouse_pos)
        target = 1.0 if self.hovered else 0.0
        self.hover_t += (target - self.hover_t) * clamp(dt * 10, 0, 1)

    def handle_click(self, mouse_pos) -> bool:
        if self.enabled and self.rect.collidepoint(mouse_pos):
            if self.callback:
                self.callback()
            return True
        return False

    def draw(self, surface: pygame.Surface) -> None:
        t = ease_out_cubic(self.hover_t)
        base_color = Color.PANEL_LIGHT if self.enabled else Color.PANEL
        border = Color.NEON_CYAN if self.enabled else Color.UI_DIM
        expand = int(3 * t)
        r = self.rect.inflate(expand, expand)
        draw_panel(surface, r, color=base_color, border_color=border, alpha=230 if self.hovered else 190)
        text_color = Color.WHITE if self.enabled else Color.UI_DIM
        draw_text(surface, self.label, r.center, size=22, color=text_color, align="center")
        if self.subtitle:
            draw_text(surface, self.subtitle, (r.centerx, r.bottom - 14), size=13, color=Color.UI_DIM, align="center")


@dataclass
class Slider:
    rect: pygame.Rect
    value: float  # 0..1
    label: str = ""
    dragging: bool = False
    on_change: Optional[Callable[[float], None]] = None

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.inflate(0, 16).collidepoint(event.pos):
                self.dragging = True
                self._set_from_mouse(event.pos[0])
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self._set_from_mouse(event.pos[0])

    def _set_from_mouse(self, mouse_x: int) -> None:
        self.value = clamp((mouse_x - self.rect.x) / self.rect.width, 0.0, 1.0)
        if self.on_change:
            self.on_change(self.value)

    def draw(self, surface: pygame.Surface) -> None:
        draw_text(surface, self.label, (self.rect.x, self.rect.y - 22), size=15, color=Color.UI_DIM)
        track = pygame.Rect(self.rect.x, self.rect.centery - 3, self.rect.width, 6)
        pygame.draw.rect(surface, (40, 42, 58), track, border_radius=3)
        fill = pygame.Rect(self.rect.x, self.rect.centery - 3, int(self.rect.width * self.value), 6)
        pygame.draw.rect(surface, Color.NEON_CYAN, fill, border_radius=3)
        knob_x = self.rect.x + int(self.rect.width * self.value)
        pygame.draw.circle(surface, Color.WHITE, (knob_x, self.rect.centery), 9)
        pygame.draw.circle(surface, Color.NEON_CYAN, (knob_x, self.rect.centery), 9, 2)
        draw_text(surface, f"{int(self.value * 100)}%", (self.rect.right + 14, self.rect.centery), size=14, align="midleft")


def draw_vertical_gradient(surface: pygame.Surface, rect: pygame.Rect, top_color, bottom_color) -> None:
    h = max(1, rect.height)
    for i in range(h):
        t = i / h
        color = tuple(int(top_color[c] + (bottom_color[c] - top_color[c]) * t) for c in range(3))
        pygame.draw.line(surface, color, (rect.x, rect.y + i), (rect.right, rect.y + i))


def draw_glow_circle(surface: pygame.Surface, pos, radius: float, color, intensity: float = 1.0) -> None:
    layers = 4
    for i in range(layers, 0, -1):
        alpha = int(40 * intensity * (i / layers))
        r = int(radius * (1 + 0.5 * (layers - i + 1) / layers))
        glow = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*color[:3], alpha), (r, r), r)
        surface.blit(glow, (pos[0] - r, pos[1] - r), special_flags=pygame.BLEND_RGBA_ADD)
