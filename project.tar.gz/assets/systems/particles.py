"""
systems/particles.py
---------------------
A lightweight, allocation-cheap particle system. Particles are stored
as plain dicts in a flat list rather than one object per particle --
with explosions spawning dozens of particles at once this keeps the
game comfortably above 60 FPS in pure Python.

ParticleSystem also owns "floating text" (damage numbers, heal
numbers, pickup labels) since they share the exact same
position/velocity/fade lifecycle as particles.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional

import pygame

from constants import Color
from utils.math_utils import clamp, random_unit_vector


@dataclass
class FloatingText:
    pos: pygame.Vector2
    text: str
    color: tuple
    life: float
    max_life: float
    vel: pygame.Vector2
    size: int = 20
    crit: bool = False


class ParticleSystem:
    def __init__(self) -> None:
        # each particle: [x, y, vx, vy, life, max_life, size, r, g, b, a, gravity, shrink]
        self._particles: list[list[float]] = []
        self._texts: list[FloatingText] = []
        self.font_cache: dict[int, pygame.font.Font] = {}

    # -- spawning -------------------------------------------------------
    def emit(
        self,
        pos: pygame.Vector2,
        count: int,
        color: tuple,
        speed_range=(60, 220),
        life_range=(0.35, 0.9),
        size_range=(2, 5),
        gravity: float = 0.0,
        spread_angle: Optional[float] = None,
        direction: Optional[pygame.Vector2] = None,
        shrink: bool = True,
    ) -> None:
        for _ in range(count):
            if direction is not None and spread_angle is not None:
                base_angle = pygame.Vector2(direction).angle_to(pygame.Vector2(1, 0))
                ang = random.uniform(-spread_angle, spread_angle)
                vel = pygame.Vector2(1, 0).rotate(-base_angle + ang)
            else:
                vel = random_unit_vector()
            speed = random.uniform(*speed_range)
            vel *= speed
            life = random.uniform(*life_range)
            size = random.uniform(*size_range)
            r, g, b = color[:3]
            self._particles.append(
                [pos.x, pos.y, vel.x, vel.y, life, life, size, r, g, b, 255, gravity, 1.0 if shrink else 0.0]
            )

    def emit_burst_ring(self, pos: pygame.Vector2, count: int, color: tuple, speed: float = 260) -> None:
        for i in range(count):
            ang = (360 / count) * i
            vel = pygame.Vector2(speed, 0).rotate(ang)
            self._particles.append(
                [pos.x, pos.y, vel.x, vel.y, 0.5, 0.5, 3, *color[:3], 255, 0.0, 1.0]
            )

    def spawn_text(
        self,
        pos: pygame.Vector2,
        text: str,
        color=Color.WHITE,
        life: float = 0.9,
        size: int = 20,
        crit: bool = False,
        vel: Optional[pygame.Vector2] = None,
    ) -> None:
        v = vel if vel is not None else pygame.Vector2(random.uniform(-20, 20), -70)
        self._texts.append(FloatingText(pygame.Vector2(pos), text, color, life, life, v, size, crit))

    # -- update / draw ----------------------------------------------------
    def update(self, dt: float) -> None:
        alive = []
        for p in self._particles:
            p[4] -= dt
            if p[4] <= 0:
                continue
            p[3] += p[11] * dt  # gravity affects vy
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[2] *= 0.94
            p[3] *= 0.94
            alive.append(p)
        self._particles = alive

        alive_texts = []
        for t in self._texts:
            t.life -= dt
            if t.life <= 0:
                continue
            t.pos += t.vel * dt
            t.vel *= 0.96
            alive_texts.append(t)
        self._texts = alive_texts

    def draw(self, surface: pygame.Surface, offset: pygame.Vector2) -> None:
        for p in self._particles:
            life_ratio = clamp(p[4] / p[5], 0.0, 1.0)
            alpha = int(255 * life_ratio)
            size = p[6] * (life_ratio if p[12] else 1.0)
            if size < 0.5:
                continue
            color = (int(p[7]), int(p[8]), int(p[9]), alpha)
            temp = pygame.Surface((int(size * 2) + 2, int(size * 2) + 2), pygame.SRCALPHA)
            pygame.draw.circle(temp, color, temp.get_rect().center, max(1, int(size)))
            surface.blit(temp, (p[0] + offset.x - temp.get_width() / 2, p[1] + offset.y - temp.get_height() / 2))

    def draw_texts(self, surface: pygame.Surface, offset: pygame.Vector2) -> None:
        for t in self._texts:
            size = t.size + (4 if t.crit else 0)
            if size not in self.font_cache:
                self.font_cache[size] = pygame.font.SysFont("arial,helvetica", size, bold=True)
            font = self.font_cache[size]
            alpha = int(255 * clamp(t.life / t.max_life, 0, 1))
            surf = font.render(t.text, True, t.color)
            surf.set_alpha(alpha)
            rect = surf.get_rect(center=(t.pos.x + offset.x, t.pos.y + offset.y))
            if t.crit:
                shadow = font.render(t.text, True, (0, 0, 0))
                shadow.set_alpha(alpha // 2)
                surface.blit(shadow, rect.move(2, 2))
            surface.blit(surf, rect)

    def clear(self) -> None:
        self._particles.clear()
        self._texts.clear()

    def __len__(self) -> int:
        return len(self._particles) + len(self._texts)
