"""
systems/collision.py
---------------------
Pure collision-detection + resolution helpers. Circle-vs-circle checks
are all we need since every entity in this game is roughly round; this
keeps collision cheap enough to brute-force at O(bullets * enemies)
even with a few hundred live bullets, which is plenty fast in
CPython for this game's entity counts.

All functions take the live game objects and mutate them in place
(apply damage, mark dead, etc.) and return small result lists so the
gameplay scene can react (spawn particles, play sounds, add score).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import pygame

from entities.bullet import Bullet, BulletManager
from entities.enemy import Enemy
from entities.boss import Boss
from entities.player import Player
from entities.powerup import PowerUp


def circles_hit(pos_a: pygame.Vector2, r_a: float, pos_b: pygame.Vector2, r_b: float) -> bool:
    return pos_a.distance_squared_to(pos_b) <= (r_a + r_b) ** 2


@dataclass
class HitResult:
    pos: pygame.Vector2
    damage: float
    crit: bool
    killed: bool
    color: tuple
    target: object


@dataclass
class CollisionResults:
    enemy_hits: list = field(default_factory=list)
    enemy_kills: list = field(default_factory=list)
    player_hits: list = field(default_factory=list)
    pickups: list = field(default_factory=list)
    explosions: list = field(default_factory=list)  # (pos, radius, damage, color)


def resolve_player_bullets_vs_enemies(
    bullets: list[Bullet], enemies: list[Enemy], boss: Optional[object]
) -> CollisionResults:
    results = CollisionResults()
    targets = list(enemies)
    if boss is not None and not boss.is_dead:
        targets.append(boss)

    for bullet in bullets:
        if bullet.lifetime <= 0:
            continue
        for target in targets:
            if getattr(target, "is_dead", False):
                continue
            if circles_hit(bullet.pos, bullet.radius, target.pos, getattr(target, "radius", 20)):
                dealt = target.take_damage(bullet.damage)
                results.enemy_hits.append(
                    HitResult(pygame.Vector2(bullet.pos), dealt, bullet.crit, target.is_dead, bullet.color, target)
                )
                if target.is_dead:
                    results.enemy_kills.append(target)

                if bullet.explosive:
                    results.explosions.append((pygame.Vector2(bullet.pos), bullet.explosion_radius, bullet.damage * 0.6, bullet.color))

                if bullet.piercing > 0:
                    bullet.piercing -= 1
                else:
                    bullet.lifetime = 0
                break
    return results


def apply_explosions(explosions: list, enemies: list[Enemy], boss: Optional[object]) -> list[HitResult]:
    hits: list[HitResult] = []
    targets = list(enemies)
    if boss is not None and not boss.is_dead:
        targets.append(boss)
    for pos, radius, damage, color in explosions:
        for target in targets:
            if getattr(target, "is_dead", False):
                continue
            dist = pos.distance_to(target.pos)
            if dist <= radius + getattr(target, "radius", 20):
                falloff = max(0.25, 1.0 - dist / (radius + 1))
                dealt = target.take_damage(damage * falloff)
                hits.append(HitResult(pygame.Vector2(target.pos), dealt, False, target.is_dead, color, target))
    return hits


def resolve_enemy_bullets_vs_player(bullets: list[Bullet], player: Player) -> list[Bullet]:
    """Returns the list of bullets that hit the player (to be removed)."""
    hit_bullets = []
    for bullet in bullets:
        if circles_hit(bullet.pos, bullet.radius, player.pos, player.radius):
            landed = player.take_damage(bullet.damage)
            if landed:
                hit_bullets.append(bullet)
            bullet.lifetime = 0
    return hit_bullets


def resolve_contact_damage(enemies: list[Enemy], boss: Optional[object], player: Player, dt: float) -> list:
    """Melee/contact damage when an enemy touches the player.

    Two things happen on contact, not just player damage:
      1. The enemy is pushed back out to the collision boundary instead
         of being left free to overlap/"stick" inside the player's hitbox
         -- previously nothing repositioned a touching enemy, so it could
         sit glued to the ship indefinitely.
      2. The enemy takes a small continuous "ram" tick of damage while
         touching (except exploders/kamikazes, which already die on
         contact). This guarantees any enemy touching the player is
         always taking damage, so a stray enemy that never lines up with
         the player's aim can't stall a wave forever.

    Returns the list of enemies that died from the contact (explosive
    death types, or ram damage finishing off something already low).
    """
    died = []
    targets = list(enemies)
    if boss is not None and not boss.is_dead:
        targets.append(boss)
    for target in targets:
        if getattr(target, "is_dead", False):
            continue
        target_radius = getattr(target, "radius", 20)
        combined_radius = target_radius + player.radius
        if circles_hit(target.pos, target_radius, player.pos, player.radius):
            player.take_damage(getattr(target, "contact_damage", 10))

            is_explosive = getattr(target, "d", None) is not None and getattr(target.d, "explosive_death", False)
            if is_explosive:
                target.health = 0
                target.is_dead = True
                died.append(target)
                continue

            # push the enemy back out to the collision boundary so it
            # can never rest fully overlapping/stuck inside the player
            push_dir = target.pos - player.pos
            if push_dir.length_squared() < 1:
                push_dir = pygame.Vector2(0, -1)
            else:
                push_dir = push_dir.normalize()
            target.pos = player.pos + push_dir * (combined_radius + 2)

            # continuous ram damage so any enemy touching the player is
            # always losing HP, even if it never lines up with player aim
            ram_damage = max(6.0, getattr(target, "contact_damage", 10) * 0.6) * dt
            dealt = target.take_damage(ram_damage) if hasattr(target, "take_damage") else 0
            if getattr(target, "is_dead", False):
                died.append(target)
    return died


def resolve_pickups(powerups: list[PowerUp], player: Player) -> list[PowerUp]:
    collected = []
    for p in powerups:
        if circles_hit(p.pos, p.radius, player.pos, player.radius):
            p.collected = True
            collected.append(p)
    return collected
