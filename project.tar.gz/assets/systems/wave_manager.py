"""
systems/wave_manager.py
------------------------
Drives the infinite wave loop: how many enemies spawn per wave, how
fast they trickle in, when a boss wave triggers, and the intermission
countdown between waves (during which the shop is available).

The manager only *decides* what to spawn and hands back EnemyDef/pos
pairs -- it does not own the enemy list itself, so gameplay.py stays
in control of the live entity collections.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

import pygame

from constants import (
    BOSS_EVERY_N_WAVES,
    SpawnEdge,
    WAVE_ENEMY_BASE_COUNT,
    WAVE_ENEMY_GROWTH,
    WAVE_INTERMISSION_TIME,
    WAVE_SPAWN_INTERVAL_BASE,
    WAVE_SPAWN_INTERVAL_MIN,
)
from entities.enemy import ENEMY_DEFS, EnemyType, pick_enemy_type
from utils.math_utils import random_point_on_edge
from utils.timer import Timer

BOSS_NAMES = [
    "Void Reaper", "Iron Leviathan", "Star Devourer", "Crimson Warden",
    "Null Sovereign", "The Harbinger", "Obsidian Wraith", "Gate Breaker",
]


class WaveState(Enum):
    INTERMISSION = auto()
    SPAWNING = auto()
    IN_PROGRESS = auto()
    BOSS_FIGHT = auto()
    WAVE_CLEAR = auto()


@dataclass
class SpawnRequest:
    enemy_type: EnemyType
    pos: pygame.Vector2


class WaveManager:
    def __init__(self, world_w: int, world_h: int, difficulty_mods: dict, rng: Optional[random.Random] = None) -> None:
        self.world_w = world_w
        self.world_h = world_h
        self.difficulty_mods = difficulty_mods
        self.rng = rng or random.Random()

        self.wave_number = 0
        self.state = WaveState.INTERMISSION
        self.intermission_timer = Timer()
        self.intermission_timer.start(3.0)

        self.enemies_to_spawn = 0
        self.enemies_spawned = 0
        self.spawn_timer = Timer()
        self.is_boss_wave = False
        self.boss_name = ""
        self.in_progress_timer = Timer()
        self.force_clear_stragglers = False

    @property
    def next_boss_in(self) -> int:
        remainder = self.wave_number % BOSS_EVERY_N_WAVES
        return BOSS_EVERY_N_WAVES - remainder if remainder != 0 else BOSS_EVERY_N_WAVES

    def start_next_wave(self) -> None:
        self.wave_number += 1
        self.force_clear_stragglers = False
        self.is_boss_wave = self.wave_number % BOSS_EVERY_N_WAVES == 0
        if self.is_boss_wave:
            self.boss_name = self.rng.choice(BOSS_NAMES)
            self.state = WaveState.BOSS_FIGHT
            self.enemies_to_spawn = 0
        else:
            self.enemies_to_spawn = int(WAVE_ENEMY_BASE_COUNT * (WAVE_ENEMY_GROWTH ** (self.wave_number - 1)))
            self.enemies_spawned = 0
            self.state = WaveState.SPAWNING
            interval = max(
                WAVE_SPAWN_INTERVAL_MIN,
                WAVE_SPAWN_INTERVAL_BASE / self.difficulty_mods.get("spawn_rate", 1.0)
                * (0.94 ** (self.wave_number - 1)),
            )
            self.spawn_timer.start(interval * 0.4)
            self._current_interval = interval

    def update(self, dt: float, enemies_alive: int, boss_alive: bool) -> list[SpawnRequest]:
        requests: list[SpawnRequest] = []

        if self.state == WaveState.INTERMISSION:
            if self.intermission_timer.update(dt):
                self.start_next_wave()

        elif self.state == WaveState.SPAWNING:
            if self.enemies_spawned < self.enemies_to_spawn:
                if self.spawn_timer.update(dt):
                    self.spawn_timer.start(self._current_interval)
                    requests.append(self._make_spawn_request())
                    self.enemies_spawned += 1
            else:
                self.state = WaveState.IN_PROGRESS
                self.in_progress_timer.start(45.0)

        elif self.state == WaveState.IN_PROGRESS:
            if enemies_alive <= 0:
                self.state = WaveState.WAVE_CLEAR
            elif self.in_progress_timer.update(dt):
                # Safety net: if a wave somehow can't naturally complete
                # (e.g. a straggler enemy the player can't reach), force
                # it closed after a generous timeout rather than soft-
                # locking the run forever. This should be effectively
                # unreachable in normal play -- it exists purely as a
                # defensive fallback.
                self.force_clear_stragglers = True
                self.state = WaveState.WAVE_CLEAR

        elif self.state == WaveState.BOSS_FIGHT:
            if not boss_alive and self.wave_number > 0:
                # boss_alive starts False before spawn; gameplay scene
                # flips a flag once the boss object exists.
                pass

        elif self.state == WaveState.WAVE_CLEAR:
            self.state = WaveState.INTERMISSION
            self.intermission_timer.start(WAVE_INTERMISSION_TIME)

        return requests

    def notify_boss_defeated(self) -> None:
        if self.state == WaveState.BOSS_FIGHT:
            self.state = WaveState.WAVE_CLEAR

    def _make_spawn_request(self) -> SpawnRequest:
        edge = self.rng.choice(list(SpawnEdge))
        pos = random_point_on_edge(edge, self.world_w, self.world_h)
        etype = pick_enemy_type(self.wave_number, self.rng)
        return SpawnRequest(etype, pos)

    def make_boss_spawn_pos(self) -> pygame.Vector2:
        return pygame.Vector2(self.world_w / 2, -120)

    def wave_scale(self) -> float:
        """General difficulty scalar applied to enemy stats, grows
        slowly forever so late waves stay dangerous."""
        return 1.0 + (self.wave_number - 1) * 0.09

    def skip_intermission(self) -> None:
        if self.state == WaveState.INTERMISSION:
            self.intermission_timer.time_left = min(self.intermission_timer.time_left, 0.4)
