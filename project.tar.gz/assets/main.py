#!/usr/bin/env python3
"""
main.py
-------
Application entry point. Initializes pygame + mixer, loads settings
and save data, builds the AppContext, and runs the scene-driven main
loop with fixed-timestep-friendly delta time.

The loop is written as an `async def main()` with a per-frame
`await asyncio.sleep(0)`. On desktop this behaves identically to a
plain while-loop (the zero-second sleep just yields once per frame).
The only reason it's async is so this exact file also runs unmodified
under pygbag (https://github.com/pygame-web/pygbag), which compiles
pygame-ce games to WebAssembly for browsers -- including mobile
browsers -- and requires that shape of loop. See README.md ("Playing
on a phone") for how to build the web/APK version.

Run on desktop with:  python main.py
"""
from __future__ import annotations

import asyncio
import sys

import pygame

from constants import FPS_CAP, GAME_TITLE
from scenes.base import AppContext, SceneManager
from scenes.menu import MenuScene
from systems.save_system import load_game, save_game
from systems.sound import SoundManager
from utils.asset_loader import init_asset_manager


async def main() -> None:
    pygame.init()
    try:
        pygame.mixer.init()
    except pygame.error:
        print("Audio device unavailable -- continuing without sound.")

    save_data = load_game()
    config = save_data.config

    init_asset_manager()

    flags = pygame.SCALED
    if config.fullscreen:
        flags |= pygame.FULLSCREEN
    screen = pygame.display.set_mode((config.screen_width, config.screen_height), flags)
    pygame.display.set_caption(GAME_TITLE)
    pygame.mouse.set_visible(True)

    clock = pygame.time.Clock()
    sound = SoundManager(config)

    ctx = AppContext(
        screen=screen,
        config=config,
        save_data=save_data,
        sound=sound,
        clock=clock,
        world_w=config.screen_width,
        world_h=config.screen_height,
    )

    manager = SceneManager(ctx)
    manager.switch(MenuScene(ctx))

    running = True
    while running:
        raw_dt = clock.tick(FPS_CAP) / 1000.0
        dt = min(raw_dt, 1 / 20)  # clamp huge spikes (e.g. window drag) to avoid physics blowups

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                manager.handle_event(event)

        manager.update(dt)
        manager.draw(screen)
        pygame.display.flip()

        # Required by pygbag's browser event loop (harmless no-op on
        # desktop -- just yields once per frame like clock.tick already
        # implies).
        await asyncio.sleep(0)

    save_data.config = config
    save_game(save_data)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
    sys.exit(0)

