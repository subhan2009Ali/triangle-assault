"""
config.py
---------
Runtime configuration that the *player* can change: video settings,
audio levels, controls, and difficulty. This is what gets written to
and loaded from the save file (see systems/save_system.py).

Keep this a plain, serializable dataclass so it can be dumped straight
to JSON without a custom encoder.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

from constants import DEFAULT_SCREEN_WIDTH, DEFAULT_SCREEN_HEIGHT

SUPPORTED_RESOLUTIONS = [
    (1024, 576),
    (1152, 648),
    (1280, 720),
    (1366, 768),
    (1600, 900),
    (1920, 1080),
]

DIFFICULTIES = ["easy", "normal", "hard", "insane"]

DIFFICULTY_MODIFIERS = {
    "easy": {"enemy_health": 0.75, "enemy_damage": 0.7, "spawn_rate": 0.8, "coin_mult": 0.9},
    "normal": {"enemy_health": 1.0, "enemy_damage": 1.0, "spawn_rate": 1.0, "coin_mult": 1.0},
    "hard": {"enemy_health": 1.35, "enemy_damage": 1.3, "spawn_rate": 1.2, "coin_mult": 1.15},
    "insane": {"enemy_health": 1.8, "enemy_damage": 1.6, "spawn_rate": 1.45, "coin_mult": 1.35},
}


@dataclass
class KeyBindings:
    pause: str = "ESCAPE"
    mute: str = "M"
    dash: str = "SPACE"
    weapon_next: str = "e"
    weapon_prev: str = "q"


@dataclass
class Config:
    # Video
    screen_width: int = DEFAULT_SCREEN_WIDTH
    screen_height: int = DEFAULT_SCREEN_HEIGHT
    fullscreen: bool = False
    vsync: bool = True
    fps_limit: int = 144
    show_fps: bool = False

    # Audio
    music_volume: float = 0.55
    sfx_volume: float = 0.8
    muted: bool = False

    # Controls
    mouse_sensitivity: float = 1.0
    bindings: KeyBindings = field(default_factory=KeyBindings)

    # Gameplay
    difficulty: str = "normal"
    screen_shake_enabled: bool = True
    damage_numbers_enabled: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Config":
        cfg = Config()
        bindings_data = data.pop("bindings", None)
        for k, v in data.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
        if bindings_data:
            cfg.bindings = KeyBindings(**bindings_data)
        return cfg

    def difficulty_mods(self) -> dict[str, float]:
        return DIFFICULTY_MODIFIERS.get(self.difficulty, DIFFICULTY_MODIFIERS["normal"])
