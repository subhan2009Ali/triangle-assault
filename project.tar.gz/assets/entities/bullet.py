"""
entities/bullet.py
-------------------
Bullets are deliberately kept as one flexible class rather than a
subclass per weapon -- a "bullet" here covers machine-gun rounds,
shotgun pellets, laser bolts, homing missiles and enemy projectiles.
What differs between them is just data (speed, damage, homing,
piercing, explosive, sprite, color) which the Weapon that spawns them
supplies.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import pygame

from utils.math_utils import clamp


@dataclass
class Bullet:
    pos: pygame.Vector2
    vel: pygame.Vector2
    damage: float
    owner: str  # "player" or "enemy"
    radius: float = 5.0
    color: tuple = (110, 220, 255)
    sprite_key: Optional[str] = None
    sprite_size: tuple = (10, 22)
    lifetime: float = 2.2
    piercing: int = 0  # number of extra enemies it can pass through
    explosive: bool = False
    explosion_radius: float = 0.0
    homing_strength: float = 0.0  # 0 = no homing, higher = tighter turn
    crit: bool = False
    trail_timer: float = 0.0
    glow: bool = True
    target_ref: object = None  # weakly-held enemy reference for homing

    def update(self, dt: float, world_w: int, world_h: int, find_target=None) -> bool:
        """Returns False when the bullet should be removed."""
        self.lifetime -= dt

        if self.homing_strength > 0:
            target = self.target_ref
            if target is None or getattr(target, "is_dead", True):
                target = find_target(self.pos) if find_target else None
                self.target_ref = target
            if target is not None and not getattr(target, "is_dead", False):
                desired = (target.pos - self.pos)
                if desired.length_squared() > 1:
                    desired = desired.normalize() * self.vel.length()
                    turn = clamp(self.homing_strength * dt, 0, 1)
                    self.vel = self.vel.lerp(desired, turn)

        self.pos += self.vel * dt
        self.trail_timer += dt

        if self.lifetime <= 0:
            return False
        margin = 80
        if (
            self.pos.x < -margin
            or self.pos.x > world_w + margin
            or self.pos.y < -margin
            or self.pos.y > world_h + margin
        ):
            return False
        return True

    @property
    def angle(self) -> float:
        return -math.degrees(math.atan2(self.vel.y, self.vel.x)) - 90

    def rect(self) -> pygame.Rect:
        r = self.radius
        return pygame.Rect(self.pos.x - r, self.pos.y - r, r * 2, r * 2)


class BulletManager:
    """Owns every live bullet (player + enemy) and updates/culls them."""

    def __init__(self) -> None:
        self.player_bullets: list[Bullet] = []
        self.enemy_bullets: list[Bullet] = []

    def add(self, bullet: Bullet) -> None:
        if bullet.owner == "player":
            self.player_bullets.append(bullet)
        else:
            self.enemy_bullets.append(bullet)

    def update(self, dt: float, world_w: int, world_h: int, find_target=None) -> None:
        self.player_bullets = [b for b in self.player_bullets if b.update(dt, world_w, world_h, find_target)]
        self.enemy_bullets = [b for b in self.enemy_bullets if b.update(dt, world_w, world_h)]

    def clear(self) -> None:
        self.player_bullets.clear()
        self.enemy_bullets.clear()

    def __len__(self) -> int:
        return len(self.player_bullets) + len(self.enemy_bullets)
