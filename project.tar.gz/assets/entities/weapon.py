"""
entities/weapon.py
-------------------
Weapon definitions and firing logic. Each Weapon knows its own fire
rate, spread pattern and bullet stats; Player just calls
`weapon.try_fire(...)` every frame and gets back a list of new Bullet
instances (empty most frames, since fire rate gates it).

Adding a new weapon = add one WEAPON_DEFS entry + (optionally) a
custom `_fire_pattern` branch if it needs bespoke behavior. Nothing
else in the codebase needs to change.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Callable, Optional

import pygame

from constants import Color, WeaponType
from entities.bullet import Bullet
from utils.timer import Timer


@dataclass
class WeaponStats:
    name: str
    weapon_type: WeaponType
    fire_rate: float  # shots per second
    damage: float
    bullet_speed: float
    spread_deg: float
    pellet_count: int
    color: tuple
    sprite_key: str
    sprite_size: tuple
    piercing: int = 0
    explosive: bool = False
    explosion_radius: float = 0.0
    is_beam: bool = False
    homing_strength: float = 0.0
    sound_keys: tuple = ("laser1", "laser2", "laser3")
    ammo_max: Optional[int] = None  # None = infinite
    description: str = ""


WEAPON_DEFS: dict[WeaponType, WeaponStats] = {
    WeaponType.MACHINE_GUN: WeaponStats(
        name="Machine Gun",
        weapon_type=WeaponType.MACHINE_GUN,
        fire_rate=8.5,
        damage=9,
        bullet_speed=780,
        spread_deg=3.0,
        pellet_count=1,
        color=Color.NEON_CYAN,
        sprite_key="spaceMissiles_017",
        sprite_size=(8, 20),
        sound_keys=("laser1", "laser2", "laser3", "laser4"),
        description="Reliable rapid-fire rounds. Low damage, high uptime.",
    ),
    WeaponType.SPREAD: WeaponStats(
        name="Spread Shot",
        weapon_type=WeaponType.SPREAD,
        fire_rate=5.5,
        damage=8,
        bullet_speed=680,
        spread_deg=10.0,
        pellet_count=3,
        color=Color.NEON_GREEN,
        sprite_key="spaceMissiles_021",
        sprite_size=(8, 18),
        sound_keys=("laser5", "laser6"),
        description="Fires three bolts in a narrow fan.",
    ),
    WeaponType.SHOTGUN: WeaponStats(
        name="Shotgun",
        weapon_type=WeaponType.SHOTGUN,
        fire_rate=2.2,
        damage=7,
        bullet_speed=620,
        spread_deg=26.0,
        pellet_count=7,
        color=Color.NEON_ORANGE,
        sprite_key="spaceMissiles_005",
        sprite_size=(7, 16),
        sound_keys=("zap1", "zap2"),
        description="Devastating up close, wide pellet spread.",
    ),
    WeaponType.LASER: WeaponStats(
        name="Laser",
        weapon_type=WeaponType.LASER,
        fire_rate=14,
        damage=5.5,
        bullet_speed=1200,
        spread_deg=0.0,
        pellet_count=1,
        color=Color.NEON_MAGENTA,
        sprite_key="spaceMissiles_037",
        sprite_size=(6, 30),
        piercing=2,
        is_beam=True,
        sound_keys=("zapThreeToneUp", "zapThreeToneDown"),
        description="Thin piercing beam that punches through enemies.",
    ),
    WeaponType.MISSILE: WeaponStats(
        name="Missile Launcher",
        weapon_type=WeaponType.MISSILE,
        fire_rate=1.6,
        damage=32,
        bullet_speed=460,
        spread_deg=4.0,
        pellet_count=1,
        color=Color.NEON_YELLOW,
        sprite_key="spaceMissiles_003",
        sprite_size=(14, 30),
        explosive=True,
        explosion_radius=90,
        homing_strength=3.2,
        sound_keys=("phaseJump1", "phaseJump2"),
        description="Slow homing missiles with area-damage impact.",
    ),
}


@dataclass
class Weapon:
    stats: WeaponStats
    level: int = 1
    cooldown: Timer = field(default_factory=Timer)
    damage_multiplier: float = 1.0
    fire_rate_multiplier: float = 1.0
    extra_pellets: int = 0
    crit_chance: float = 0.05
    crit_multiplier: float = 2.0
    piercing_bonus: int = 0
    homing_override: Optional[float] = None

    def upgrade(self) -> None:
        self.level += 1
        self.damage_multiplier += 0.18
        self.fire_rate_multiplier += 0.08

    def try_fire(self, pos: pygame.Vector2, aim_dir: pygame.Vector2) -> list[Bullet]:
        rate = self.stats.fire_rate * self.fire_rate_multiplier
        if rate <= 0:
            return []
        if not self.cooldown.active:
            self.cooldown.start(1.0 / rate)
            return self._fire_pattern(pos, aim_dir)
        return []

    def force_ready(self) -> None:
        self.cooldown.time_left = 0

    def update(self, dt: float) -> None:
        self.cooldown.update(dt)

    def _fire_pattern(self, pos: pygame.Vector2, aim_dir: pygame.Vector2) -> list[Bullet]:
        bullets: list[Bullet] = []
        pellets = self.stats.pellet_count + self.extra_pellets
        spread = self.stats.spread_deg
        base_angle = aim_dir.angle_to(pygame.Vector2(1, 0))

        for i in range(pellets):
            if pellets == 1:
                offset = random.uniform(-spread, spread) if spread else 0
            else:
                t = i / (pellets - 1) - 0.5
                offset = t * spread * 2 + random.uniform(-1.5, 1.5)
            vel_dir = pygame.Vector2(1, 0).rotate(-base_angle + offset)
            velocity = vel_dir * self.stats.bullet_speed

            is_crit = random.random() < self.crit_chance
            dmg = self.stats.damage * self.damage_multiplier
            if is_crit:
                dmg *= self.crit_multiplier

            bullets.append(
                Bullet(
                    pos=pygame.Vector2(pos),
                    vel=velocity,
                    damage=dmg,
                    owner="player",
                    radius=max(3, self.stats.sprite_size[0] / 2),
                    color=self.stats.color,
                    sprite_key=self.stats.sprite_key,
                    sprite_size=self.stats.sprite_size,
                    piercing=self.stats.piercing + self.piercing_bonus,
                    explosive=self.stats.explosive,
                    explosion_radius=self.stats.explosion_radius,
                    homing_strength=self.homing_override if self.homing_override is not None else self.stats.homing_strength,
                    crit=is_crit,
                )
            )
        return bullets

    def ammo_label(self) -> str:
        return "∞"


def make_weapon(weapon_type: WeaponType) -> Weapon:
    return Weapon(stats=WEAPON_DEFS[weapon_type])
