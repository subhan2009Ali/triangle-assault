"""
entities/player.py
-------------------
The player's triangle-ish spaceship. Handles smooth accel/decel
movement toward the mouse-relative input vector, rotation to face the
cursor, weapon switching/firing, health/shield/armor/lives, and the
active status-effect stack driven by power-ups.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pygame

from constants import (
    Color,
    PLAYER_ACCELERATION,
    PLAYER_BASE_ARMOR,
    PLAYER_BASE_HEALTH,
    PLAYER_BASE_LIVES,
    PLAYER_BASE_SHIELD,
    PLAYER_DRAG,
    PLAYER_HIT_FLASH_DURATION,
    PLAYER_IFRAME_DURATION,
    PLAYER_MAX_SPEED,
    PLAYER_RADIUS,
    PLAYER_ROTATION_SMOOTH,
    WORLD_MARGIN,
    WeaponType,
)
from entities.weapon import Weapon, make_weapon
from utils.asset_loader import assets
from utils.math_utils import clamp, lerp_angle
from utils.timer import Timer


@dataclass
class StatusEffects:
    """Timed buffs applied by power-ups. Each field is a Timer; a
    field is "active" while its timer has time left."""
    rapid_fire: Timer = field(default_factory=Timer)
    double_damage: Timer = field(default_factory=Timer)
    triple_shot: Timer = field(default_factory=Timer)
    homing: Timer = field(default_factory=Timer)
    speed_boost: Timer = field(default_factory=Timer)
    slow_motion: Timer = field(default_factory=Timer)
    magnet: Timer = field(default_factory=Timer)
    invincibility: Timer = field(default_factory=Timer)
    regen: Timer = field(default_factory=Timer)
    reflect: Timer = field(default_factory=Timer)
    coin_boost: Timer = field(default_factory=Timer)

    def update(self, dt: float) -> None:
        for f in self.__dataclass_fields__:
            getattr(self, f).update(dt)


class Player:
    def __init__(self, world_w: int, world_h: int, upgrades=None) -> None:
        self.world_w = world_w
        self.world_h = world_h
        self.pos = pygame.Vector2(world_w / 2, world_h / 2)
        self.vel = pygame.Vector2(0, 0)
        self.angle = -90.0  # facing "up" initially
        self.radius = PLAYER_RADIUS

        upg = upgrades
        health_bonus = (upg.max_health * 12) if upg else 0
        self.max_health = PLAYER_BASE_HEALTH + health_bonus
        self.health = self.max_health
        self.armor = PLAYER_BASE_ARMOR + ((upg.shield_capacity if upg else 0))
        self.max_shield = PLAYER_BASE_SHIELD + ((upg.shield_capacity * 15) if upg else 0)
        self.shield = self.max_shield * 0.5 if self.max_shield else 0
        self.lives = PLAYER_BASE_LIVES
        self.max_speed = PLAYER_MAX_SPEED + ((upg.move_speed * 18) if upg else 0)

        self.level = 1
        self.xp = 0
        self.xp_to_next = 60
        self.coins = 0
        self.score = 0

        self.iframe_timer = Timer()
        self.hit_flash_timer = Timer()
        self.status = StatusEffects()

        self.damage_multiplier = 1.0 + ((upg.damage * 0.06) if upg else 0)
        self.crit_bonus = (upg.crit_chance * 0.02) if upg else 0
        self.xp_gain_mult = 1.0 + ((upg.xp_gain * 0.08) if upg else 0)
        self.coin_mult = 1.0 + ((upg.coin_multiplier * 0.08) if upg else 0)
        self.energy_regen_bonus = (upg.energy_regen if upg else 0)
        self.luck = (upg.luck if upg else 0)

        self.weapons: dict[WeaponType, Weapon] = {WeaponType.MACHINE_GUN: make_weapon(WeaponType.MACHINE_GUN)}
        self.current_weapon_type = WeaponType.MACHINE_GUN
        for wt, w in self.weapons.items():
            w.crit_chance += self.crit_bonus

        self.is_dead = False
        self.is_moving = False
        self.thruster_pulse = 0.0
        self.orbiting_shield_active = False
        self.drone_timer = Timer()

    # -- weapons ----------------------------------------------------------
    @property
    def weapon(self) -> Weapon:
        return self.weapons[self.current_weapon_type]

    def unlock_weapon(self, weapon_type: WeaponType) -> None:
        if weapon_type not in self.weapons:
            w = make_weapon(weapon_type)
            w.crit_chance += self.crit_bonus
            self.weapons[weapon_type] = w

    def switch_weapon(self, direction: int) -> None:
        order = list(self.weapons.keys())
        if len(order) <= 1:
            return
        idx = order.index(self.current_weapon_type)
        idx = (idx + direction) % len(order)
        self.current_weapon_type = order[idx]

    def apply_weapon_pickup(self, weapon_type: WeaponType) -> None:
        self.unlock_weapon(weapon_type)
        self.current_weapon_type = weapon_type

    # -- movement -----------------------------------------------------
    def update_movement(self, dt: float, target_pos: pygame.Vector2, extra_input: pygame.Vector2 | None = None) -> None:
        """The ship eases toward `target_pos` (the mouse cursor) with
        acceleration + drag rather than snapping to it, so movement
        reads as inertial flight instead of teleporting. `extra_input`
        (optional WASD vector) is added on top for players who prefer
        direct control; both can be used together."""
        speed_cap = self.max_speed
        if self.status.speed_boost.active:
            speed_cap *= 1.6

        to_target = target_pos - self.pos
        dist = to_target.length()
        dead_zone = 6.0

        self.is_moving = dist > dead_zone
        if self.is_moving:
            direction = to_target / dist if dist > 0 else pygame.Vector2()
            # ease acceleration as we approach the cursor so the ship
            # settles instead of oscillating around it
            accel_scale = clamp(dist / 140.0, 0.15, 1.0)
            self.vel += direction * PLAYER_ACCELERATION * accel_scale * dt

        if extra_input and extra_input.length_squared() > 0.0001:
            self.vel += extra_input.normalize() * PLAYER_ACCELERATION * 0.6 * dt
            self.is_moving = True

        drag = 1.0 / (1.0 + PLAYER_DRAG * dt)
        self.vel *= drag

        if self.vel.length() > speed_cap:
            self.vel.scale_to_length(speed_cap)

        self.pos += self.vel * dt
        self.pos.x = clamp(self.pos.x, WORLD_MARGIN, self.world_w - WORLD_MARGIN)
        self.pos.y = clamp(self.pos.y, WORLD_MARGIN, self.world_h - WORLD_MARGIN)

        self.thruster_pulse += dt * 12

    def update_rotation(self, dt: float, target_pos: pygame.Vector2) -> None:
        delta = target_pos - self.pos
        if delta.length_squared() < 0.01:
            return
        # pygame rotate() is counter-clockwise for positive angles with +Y down,
        # sprite drawn nose-up, so target angle needs the -90 offset & flip.
        target_angle = -delta.angle_to(pygame.Vector2(1, 0)) - 90
        t = clamp(PLAYER_ROTATION_SMOOTH * dt, 0, 1)
        self.angle = lerp_angle(self.angle, target_angle, t)
        self.angle = (self.angle + 180) % 360 - 180

    def facing_vector(self) -> pygame.Vector2:
        import math

        rad = math.radians(self.angle + 90)
        return pygame.Vector2(math.cos(rad), math.sin(rad))

    # -- combat -------------------------------------------------------
    def take_damage(self, amount: float) -> bool:
        """Returns True if the hit actually landed (not blocked by
        iframes/invincibility)."""
        if self.status.invincibility.active or self.iframe_timer.active:
            return False
        remaining = amount
        if self.shield > 0:
            absorbed = min(self.shield, remaining)
            self.shield -= absorbed
            remaining -= absorbed
        if self.armor > 0 and remaining > 0:
            remaining = max(0.0, remaining - self.armor)
        if remaining > 0:
            self.health -= remaining
        self.iframe_timer.start(PLAYER_IFRAME_DURATION)
        self.hit_flash_timer.start(PLAYER_HIT_FLASH_DURATION)
        if self.health <= 0:
            self.health = 0
            self._lose_life()
        return True

    def _lose_life(self) -> None:
        self.lives -= 1
        if self.lives <= 0:
            self.is_dead = True
        else:
            self.health = self.max_health * 0.6
            self.iframe_timer.start(PLAYER_IFRAME_DURATION * 2.2)

    def heal(self, amount: float) -> None:
        self.health = min(self.max_health, self.health + amount)

    def add_shield(self, amount: float) -> None:
        self.max_shield = max(self.max_shield, 40)
        self.shield = min(self.max_shield, self.shield + amount)

    def add_xp(self, amount: float) -> bool:
        """Returns True if the player leveled up."""
        self.xp += amount * self.xp_gain_mult
        leveled = False
        while self.xp >= self.xp_to_next:
            self.xp -= self.xp_to_next
            self.level += 1
            self.xp_to_next = int(self.xp_to_next * 1.18)
            leveled = True
        return leveled

    def add_coins(self, amount: int) -> None:
        mult = self.coin_mult
        if self.status.coin_boost.active:
            mult *= 2.0
        self.coins += max(1, int(amount * mult)) if amount > 0 else 0

    def update_status(self, dt: float) -> None:
        self.status.update(dt)
        self.iframe_timer.update(dt)
        self.hit_flash_timer.update(dt)

        if self.status.regen.active:
            self.heal(14 * dt)

        if self.energy_regen_bonus and self.max_shield > 0:
            self.shield = min(self.max_shield, self.shield + self.energy_regen_bonus * 2 * dt)

        current_fire_mult = 2.4 if self.status.rapid_fire.active else 1.0
        for w in self.weapons.values():
            w.fire_rate_multiplier = max(w.fire_rate_multiplier, 1.0)
        self.weapon.fire_rate_multiplier = 1.0 + (self.weapon.level - 1) * 0.08
        if self.status.rapid_fire.active:
            self.weapon.fire_rate_multiplier *= current_fire_mult

        dmg_mult = self.damage_multiplier
        if self.status.double_damage.active:
            dmg_mult *= 2.0
        self.weapon.damage_multiplier = dmg_mult + (self.weapon.level - 1) * 0.18

        self.weapon.extra_pellets = 2 if self.status.triple_shot.active else 0
        self.weapon.homing_override = 5.5 if self.status.homing.active else None

        for w in self.weapons.values():
            w.update(dt)

    def try_fire(self):
        origin = self.pos + self.facing_vector() * (self.radius * 0.9)
        return self.weapon.try_fire(origin, self.facing_vector())

    def rect(self) -> pygame.Rect:
        r = self.radius
        return pygame.Rect(self.pos.x - r, self.pos.y - r, r * 2, r * 2)

    # -- rendering ------------------------------------------------------
    def get_sprite(self, size: int = 64) -> pygame.Surface:
        return assets.get_image("spaceShips_001", (size, size))
