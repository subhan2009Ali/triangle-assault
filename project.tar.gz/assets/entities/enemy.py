"""
entities/enemy.py
------------------
All non-boss enemy types share one Enemy class; behavior differences
come from an EnemyDef (stats + an `ai` tag) so adding a new enemy type
is just adding one EnemyDef entry plus, if it needs genuinely new
logic, one branch in `_update_ai`.

AI archetypes implemented:
  chase      - beeline straight for the player (SMALL, FAST, TANK, ELITE)
  shooter    - keep medium range, strafe, fire at player
  sniper     - keep long range, fire slow high-damage shots
  kamikaze   - accelerate hard toward player, explode on contact
  exploder   - like chase, but explodes into a damaging ring on death
  shield     - chase, but periodically raises a damage-blocking shield
  healer     - stays at range, periodically heals nearby enemies
  drift      - asteroids: slow straight-line drift, no targeting
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Optional

import pygame

from constants import Color, EnemyType
from entities.bullet import Bullet
from utils.math_utils import clamp, distance
from utils.timer import Timer


@dataclass
class EnemyDef:
    enemy_type: EnemyType
    name: str
    ai: str
    base_health: float
    base_damage: float
    speed: float
    radius: float
    color: tuple
    sprite_key: str
    xp_reward: int
    coin_reward: int
    score_reward: int
    contact_damage: float
    fire_rate: float = 0.0
    bullet_speed: float = 320.0
    preferred_range: float = 0.0
    explosive_death: bool = False
    shield_hp: float = 0.0
    rotates: bool = True
    scale: float = 1.0
    description: str = ""


ENEMY_DEFS: dict[EnemyType, EnemyDef] = {
    EnemyType.SMALL: EnemyDef(
        EnemyType.SMALL, "Scout", "chase", base_health=18, base_damage=8, speed=190,
        radius=16, color=Color.NEON_CYAN, sprite_key="spaceShips_008", xp_reward=6,
        coin_reward=2, score_reward=10, contact_damage=8, scale=0.55,
        description="Weak but numerous.",
    ),
    EnemyType.FAST: EnemyDef(
        EnemyType.FAST, "Interceptor", "chase", base_health=14, base_damage=6, speed=320,
        radius=15, color=Color.NEON_YELLOW, sprite_key="spaceShips_002", xp_reward=7,
        coin_reward=3, score_reward=14, contact_damage=6, scale=0.5,
        description="Very fast, low HP.",
    ),
    EnemyType.TANK: EnemyDef(
        EnemyType.TANK, "Bulwark", "chase", base_health=140, base_damage=18, speed=90,
        radius=30, color=Color.NEON_PURPLE, sprite_key="spaceShips_004", xp_reward=22,
        coin_reward=9, score_reward=40, contact_damage=18, scale=0.95,
        description="Slow, heavily armored.",
    ),
    EnemyType.SHOOTER: EnemyDef(
        EnemyType.SHOOTER, "Gunship", "shooter", base_health=40, base_damage=10, speed=140,
        radius=20, color=Color.NEON_ORANGE, sprite_key="spaceShips_005", xp_reward=14,
        coin_reward=5, score_reward=25, contact_damage=10, fire_rate=1.1,
        bullet_speed=340, preferred_range=280, scale=0.7,
        description="Keeps distance and fires.",
    ),
    EnemyType.SNIPER: EnemyDef(
        EnemyType.SNIPER, "Marksman", "sniper", base_health=30, base_damage=26, speed=110,
        radius=18, color=Color.NEON_RED, sprite_key="spaceShips_009", xp_reward=18,
        coin_reward=7, score_reward=32, contact_damage=10, fire_rate=0.55,
        bullet_speed=620, preferred_range=460, scale=0.65,
        description="Long range, heavy hits.",
    ),
    EnemyType.EXPLODER: EnemyDef(
        EnemyType.EXPLODER, "Detonator", "exploder", base_health=26, base_damage=0, speed=170,
        radius=18, color=Color.NEON_ORANGE, sprite_key="spaceShips_003", xp_reward=12,
        coin_reward=5, score_reward=22, contact_damage=26, explosive_death=True, scale=0.65,
        description="Explodes violently on death or contact.",
    ),
    EnemyType.KAMIKAZE: EnemyDef(
        EnemyType.KAMIKAZE, "Ravager", "kamikaze", base_health=22, base_damage=0, speed=260,
        radius=17, color=Color.NEON_RED, sprite_key="spaceShips_006", xp_reward=10,
        coin_reward=4, score_reward=20, contact_damage=30, explosive_death=True, scale=0.6,
        description="Charges and detonates on impact.",
    ),
    EnemyType.SHIELD: EnemyDef(
        EnemyType.SHIELD, "Aegis", "shield", base_health=60, base_damage=12, speed=130,
        radius=22, color=Color.NEON_BLUE, sprite_key="spaceShips_007", xp_reward=20,
        coin_reward=8, score_reward=36, contact_damage=12, shield_hp=50, scale=0.85,
        description="Periodically shields itself.",
    ),
    EnemyType.HEALER: EnemyDef(
        EnemyType.HEALER, "Medic Drone", "healer", base_health=35, base_damage=0, speed=120,
        radius=18, color=Color.NEON_GREEN, sprite_key="spaceShips_001", xp_reward=16,
        coin_reward=6, score_reward=30, contact_damage=6, preferred_range=260, scale=0.6,
        description="Heals nearby enemies.",
    ),
    EnemyType.ELITE: EnemyDef(
        EnemyType.ELITE, "Elite Warden", "shooter", base_health=110, base_damage=16, speed=170,
        radius=24, color=Color.NEON_MAGENTA, sprite_key="spaceShips_007", xp_reward=34,
        coin_reward=14, score_reward=60, contact_damage=16, fire_rate=1.6,
        bullet_speed=420, preferred_range=240, scale=0.9,
        description="A dangerous all-rounder.",
    ),
    EnemyType.ASTEROID: EnemyDef(
        EnemyType.ASTEROID, "Asteroid", "drift", base_health=45, base_damage=0, speed=70,
        radius=26, color=Color.ARMOR, sprite_key="spaceMeteors_001", xp_reward=5,
        coin_reward=2, score_reward=8, contact_damage=20, rotates=False, scale=1.0,
        description="Drifting space debris.",
    ),
}


class Enemy:
    def __init__(self, enemy_def: EnemyDef, pos: pygame.Vector2, difficulty_mods: dict, wave_scale: float = 1.0) -> None:
        self.d = enemy_def
        self.pos = pygame.Vector2(pos)
        self.vel = pygame.Vector2(0, 0)
        self.angle = 0.0

        health_scale = difficulty_mods.get("enemy_health", 1.0) * wave_scale
        dmg_scale = difficulty_mods.get("enemy_damage", 1.0) * (1.0 + (wave_scale - 1.0) * 0.5)

        self.max_health = enemy_def.base_health * health_scale
        self.health = self.max_health
        self.damage = enemy_def.base_damage * dmg_scale
        self.contact_damage = enemy_def.contact_damage * dmg_scale
        self.speed = enemy_def.speed
        self.radius = enemy_def.radius

        self.shield_hp = enemy_def.shield_hp * health_scale
        self.shield_max = self.shield_hp
        self.shield_timer = Timer()
        self.shield_active = self.shield_hp > 0
        if self.shield_active:
            self.shield_timer.start(random.uniform(2.5, 4.5))

        self.fire_timer = Timer()
        if enemy_def.fire_rate > 0:
            self.fire_timer.start(random.uniform(0.4, 1.2) / enemy_def.fire_rate)
        self.heal_timer = Timer()
        if enemy_def.ai == "healer":
            self.heal_timer.start(2.0)

        self.strafe_dir = random.choice([-1, 1])
        self.strafe_timer = Timer()
        self.strafe_timer.start(random.uniform(1.0, 2.4))

        self.is_dead = False
        self.death_processed = False
        self.hit_flash = Timer()
        self.spawn_anim = Timer()
        self.spawn_anim.start(0.35)
        self.frozen_timer = Timer()
        self.spin = random.uniform(-40, 40)

    # -- damage -----------------------------------------------------------
    def take_damage(self, amount: float) -> float:
        """Apply damage (shield first). Returns actual HP damage dealt."""
        if self.shield_active and self.shield_hp > 0:
            absorbed = min(self.shield_hp, amount)
            self.shield_hp -= absorbed
            amount -= absorbed
            if self.shield_hp <= 0:
                self.shield_active = False
                self.shield_timer.start(random.uniform(4.0, 7.0))
        dealt = min(self.health, amount)
        self.health -= amount
        self.hit_flash.start(0.08)
        if self.health <= 0:
            self.is_dead = True
        return dealt

    # -- AI ---------------------------------------------------------------
    def update(self, dt: float, player_pos: pygame.Vector2, world_w: int, world_h: int, all_enemies=None):
        self.hit_flash.update(dt)
        self.spawn_anim.update(dt)
        self.frozen_timer.update(dt)
        if self.frozen_timer.active:
            return None

        if self.d.shield_hp > 0:
            if self.shield_timer.update(dt):
                if not self.shield_active:
                    self.shield_active = True
                    self.shield_hp = self.shield_max
                    self.shield_timer.start(random.uniform(2.5, 4.5))
                else:
                    self.shield_active = False
                    self.shield_timer.start(random.uniform(4.0, 7.0))

        new_bullet = None
        to_player = player_pos - self.pos
        dist = to_player.length()
        direction = to_player.normalize() if dist > 1 else pygame.Vector2(0, -1)

        ai = self.d.ai
        if ai == "chase":
            self.vel = direction * self.speed
        elif ai == "kamikaze":
            self.speed = min(self.speed + 90 * dt, self.d.speed * 2.1)
            self.vel = direction * self.speed
        elif ai == "drift":
            if self.vel.length_squared() < 1:
                ang = random.uniform(0, math.tau)
                self.vel = pygame.Vector2(math.cos(ang), math.sin(ang)) * self.speed
        elif ai == "exploder":
            self.vel = direction * self.speed
        elif ai == "shield":
            self.vel = direction * self.speed * 0.9
        elif ai in ("shooter", "sniper", "healer"):
            pref = self.d.preferred_range or 300
            if dist > pref + 40:
                self.vel = direction * self.speed
            elif dist < pref - 40:
                self.vel = -direction * self.speed * 0.8
            else:
                if self.strafe_timer.update(dt):
                    self.strafe_dir *= -1
                    self.strafe_timer.start(random.uniform(1.0, 2.4))
                tangent = pygame.Vector2(-direction.y, direction.x) * self.strafe_dir
                self.vel = tangent * self.speed * 0.7

            if self.d.fire_rate > 0 and self.fire_timer.update(dt):
                self.fire_timer.start(1.0 / self.d.fire_rate)
                new_bullet = Bullet(
                    pos=pygame.Vector2(self.pos),
                    vel=direction * self.d.bullet_speed,
                    damage=self.damage,
                    owner="enemy",
                    radius=6 if ai != "sniper" else 5,
                    color=Color.NEON_RED if ai != "sniper" else Color.NEON_ORANGE,
                    sprite_key="spaceMissiles_009",
                    sprite_size=(8, 18),
                )

            if ai == "healer" and self.heal_timer.update(dt):
                self.heal_timer.start(3.0)
                if all_enemies:
                    for other in all_enemies:
                        if other is not self and not other.is_dead and distance(other.pos, self.pos) < 220:
                            other.health = min(other.max_health, other.health + other.max_health * 0.18)

        # keep enemies from clumping perfectly on top of each other
        if all_enemies and ai != "drift":
            sep = pygame.Vector2(0, 0)
            for other in all_enemies:
                if other is self or other.is_dead:
                    continue
                d = self.pos.distance_to(other.pos)
                if 0 < d < (self.radius + other.radius) * 1.4:
                    push = (self.pos - other.pos)
                    if push.length_squared() > 0:
                        sep += push.normalize() / max(d, 1)
            if sep.length_squared() > 0:
                self.vel += sep * 260

        # hard velocity cap -- prevents the separation impulse above (or,
        # for "drift" enemies whose vel persists across frames instead of
        # being reset by AI each tick) from ever accumulating into a
        # runaway speed
        max_speed = self.d.speed * 2.4
        if self.vel.length_squared() > max_speed * max_speed:
            self.vel.scale_to_length(max_speed)

        self.pos += self.vel * dt

        # "drift" enemies (asteroids) have no player-seeking logic to pull
        # them back into play, so a plain position-clamp at the world
        # boundary would leave them permanently parked in a corner with
        # velocity still pointed into the wall -- unreachable forever, and
        # silently blocking wave completion. Bounce them off the boundary
        # instead so they always stay in circulation. Other AI types still
        # get the plain clamp since their movement is actively re-aimed at
        # the player every frame and can't get wall-stuck the same way.
        margin = 90
        if ai == "drift":
            if self.pos.x <= -margin or self.pos.x >= world_w + margin:
                self.vel.x *= -1
            if self.pos.y <= -margin or self.pos.y >= world_h + margin:
                self.vel.y *= -1
        self.pos.x = clamp(self.pos.x, -margin, world_w + margin)
        self.pos.y = clamp(self.pos.y, -margin, world_h + margin)

        if self.d.rotates:
            target_angle = -direction.angle_to(pygame.Vector2(1, 0)) - 90
            self.angle = target_angle
        else:
            self.angle += self.spin * dt

        return new_bullet

    def rect(self) -> pygame.Rect:
        r = self.radius
        return pygame.Rect(self.pos.x - r, self.pos.y - r, r * 2, r * 2)

    def health_ratio(self) -> float:
        return clamp(self.health / self.max_health, 0, 1) if self.max_health else 0

    def freeze(self, duration: float) -> None:
        self.frozen_timer.start(duration)


def pick_enemy_type(wave: int, rng: random.Random) -> EnemyType:
    """Weighted random enemy type selection that unlocks new types as
    waves progress, keeping early waves simple."""
    pool: list[tuple[EnemyType, float]] = [(EnemyType.SMALL, 10), (EnemyType.FAST, 6)]
    if wave >= 2:
        pool.append((EnemyType.SHOOTER, 5))
    if wave >= 3:
        pool.append((EnemyType.EXPLODER, 4))
    if wave >= 3:
        pool.append((EnemyType.ASTEROID, 5))
    if wave >= 4:
        pool.append((EnemyType.TANK, 3))
    if wave >= 5:
        pool.append((EnemyType.KAMIKAZE, 4))
    if wave >= 6:
        pool.append((EnemyType.SNIPER, 3))
    if wave >= 7:
        pool.append((EnemyType.SHIELD, 3))
    if wave >= 8:
        pool.append((EnemyType.HEALER, 2))
    if wave >= 9:
        pool.append((EnemyType.ELITE, 2))

    total = sum(w for _, w in pool)
    r = rng.uniform(0, total)
    upto = 0.0
    for et, w in pool:
        upto += w
        if r <= upto:
            return et
    return EnemyType.SMALL
