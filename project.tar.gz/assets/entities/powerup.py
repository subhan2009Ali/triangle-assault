"""
entities/powerup.py
--------------------
Power-up pickups that drop from enemies. Each PowerUpDef carries its
own icon color/label, duration, and a short description shown when it
is picked up. PowerUp entities themselves just bob/rotate in place
until collected or their lifetime expires.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass

import pygame

from constants import Color, PowerUpType, WeaponType
from utils.timer import Timer

POWERUP_LIFETIME = 9.0


@dataclass
class PowerUpDef:
    kind: PowerUpType
    label: str
    color: tuple
    duration: float  # 0 = instant effect, no timer
    description: str
    weight: float = 1.0


POWERUP_DEFS: dict[PowerUpType, PowerUpDef] = {
    PowerUpType.HEALTH: PowerUpDef(PowerUpType.HEALTH, "HP", Color.HEALTH, 0, "Restores health.", 3.0),
    PowerUpType.SHIELD_BOOST: PowerUpDef(PowerUpType.SHIELD_BOOST, "SHLD", Color.SHIELD, 0, "Grants energy shield.", 2.0),
    PowerUpType.RAPID_FIRE: PowerUpDef(PowerUpType.RAPID_FIRE, "RAPID", Color.NEON_YELLOW, 8.0, "Massively increased fire rate."),
    PowerUpType.DOUBLE_DAMAGE: PowerUpDef(PowerUpType.DOUBLE_DAMAGE, "2xDMG", Color.NEON_RED, 8.0, "Double weapon damage."),
    PowerUpType.TRIPLE_SHOT: PowerUpDef(PowerUpType.TRIPLE_SHOT, "TRI", Color.NEON_GREEN, 9.0, "Fires extra projectiles."),
    PowerUpType.HOMING: PowerUpDef(PowerUpType.HOMING, "HOMING", Color.NEON_PURPLE, 8.0, "Bullets track enemies."),
    PowerUpType.SPEED_BOOST: PowerUpDef(PowerUpType.SPEED_BOOST, "SPD", Color.NEON_CYAN, 8.0, "Increased movement speed."),
    PowerUpType.SLOW_MOTION: PowerUpDef(PowerUpType.SLOW_MOTION, "SLOW", Color.NEON_BLUE, 4.0, "Slows down time."),
    PowerUpType.MAGNET: PowerUpDef(PowerUpType.MAGNET, "MAGNET", Color.COIN, 10.0, "Auto-collects nearby pickups."),
    PowerUpType.FREEZE: PowerUpDef(PowerUpType.FREEZE, "FREEZE", Color.NEON_BLUE, 4.0, "Freezes all enemies."),
    PowerUpType.BOMB: PowerUpDef(PowerUpType.BOMB, "BOMB", Color.NEON_ORANGE, 0, "Damages all enemies on screen.", 0.6),
    PowerUpType.INVINCIBILITY: PowerUpDef(PowerUpType.INVINCIBILITY, "INVINC", Color.WHITE, 5.0, "Completely invulnerable.", 0.7),
    PowerUpType.EXTRA_LIFE: PowerUpDef(PowerUpType.EXTRA_LIFE, "1UP", Color.NEON_MAGENTA, 0, "Grants an extra life.", 0.3),
    PowerUpType.COIN_MULTIPLIER: PowerUpDef(PowerUpType.COIN_MULTIPLIER, "COINx2", Color.COIN, 12.0, "Doubles coin pickups."),
    PowerUpType.REGEN: PowerUpDef(PowerUpType.REGEN, "REGEN", Color.HEALTH, 8.0, "Gradually heals over time."),
}


class PowerUp:
    def __init__(self, pos: pygame.Vector2, kind: PowerUpType) -> None:
        self.pos = pygame.Vector2(pos)
        self.kind = kind
        self.d = POWERUP_DEFS[kind]
        self.radius = 16
        self.lifetime = Timer()
        self.lifetime.start(POWERUP_LIFETIME)
        self.bob_phase = random.uniform(0, math.tau)
        self.collected = False
        self.vel = pygame.Vector2(0, 0)
        self.custom_label: str | None = None  # overrides d.label for display without mutating the shared def
        self.weapon_reward = None  # set externally for weapon-unlock pickups

    def update(self, dt: float, player_pos: pygame.Vector2, magnet_active: bool) -> bool:
        """Returns False when the pickup should be removed (expired)."""
        self.bob_phase += dt * 3.2
        expired = self.lifetime.update(dt)

        to_player = player_pos - self.pos
        dist = to_player.length()
        pull_radius = 260 if magnet_active else 70
        if dist < pull_radius and dist > 1:
            strength = 720 if magnet_active else 200
            self.vel = to_player.normalize() * strength
            self.pos += self.vel * dt
        return not expired

    def rect(self) -> pygame.Rect:
        r = self.radius
        return pygame.Rect(self.pos.x - r, self.pos.y - r, r * 2, r * 2)

    def bob_offset(self) -> float:
        return math.sin(self.bob_phase) * 4

    def display_label(self) -> str:
        return self.custom_label or self.d.label


def roll_drop(rng: random.Random, luck: int = 0) -> PowerUpType | None:
    """Enemies have a base chance to drop a power-up; luck upgrades
    raise the odds slightly."""
    base_chance = 0.16 + luck * 0.01
    if rng.random() > base_chance:
        return None
    kinds = list(POWERUP_DEFS.values())
    total = sum(k.weight for k in kinds)
    r = rng.uniform(0, total)
    upto = 0.0
    for k in kinds:
        upto += k.weight
        if r <= upto:
            return k.kind
    return kinds[-1].kind


WEAPON_PICKUP_CHANCE = 0.05
