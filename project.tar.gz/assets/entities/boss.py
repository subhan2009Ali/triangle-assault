"""
entities/boss.py
-----------------
Boss encounters. A Boss cycles through a state machine of attack
patterns (spread barrage, laser sweep, charge, shockwave, minion
summon, shield phase) on cooldown, and permanently shifts into
"enrage" once its HP drops below 30%, becoming faster and more
aggressive.

Mini-bosses reuse the exact same class with a smaller stat multiplier
and a trimmed attack pool (see make_boss(..., mini=True)).
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum, auto

import pygame

from constants import Color, EnemyType
from entities.bullet import Bullet
from utils.math_utils import clamp
from utils.timer import Timer


class BossPhase(Enum):
    APPROACH = auto()
    SPREAD_BARRAGE = auto()
    LASER_SWEEP = auto()
    CHARGE = auto()
    SHOCKWAVE = auto()
    SUMMON = auto()
    SHIELD = auto()
    COOLDOWN = auto()


@dataclass
class BossEvents:
    bullets: list = field(default_factory=list)
    summon_requests: int = 0
    shockwave_triggered: bool = False
    charge_started: bool = False
    charge_hit: bool = False
    enraged_this_frame: bool = False
    died_this_frame: bool = False


class Boss:
    def __init__(self, name: str, pos: pygame.Vector2, wave: int, difficulty_mods: dict, mini: bool = False) -> None:
        self.name = name
        self.pos = pygame.Vector2(pos)
        self.vel = pygame.Vector2(0, 0)
        self.angle = 90.0
        self.mini = mini

        base_hp = 900 if not mini else 260
        growth = 1.0 + (wave // 5) * 0.35
        self.max_health = base_hp * growth * difficulty_mods.get("enemy_health", 1.0)
        self.health = self.max_health
        self.damage = (22 if not mini else 14) * difficulty_mods.get("enemy_damage", 1.0)
        self.radius = 56 if not mini else 34
        self.speed = 90 if not mini else 130
        self.sprite_key = "spaceShips_007" if not mini else "spaceShips_009"
        self.contact_damage = self.damage

        self.phase = BossPhase.APPROACH
        self.phase_timer = Timer()
        self.phase_timer.start(1.8)
        self.cooldown_timer = Timer()

        self.enraged = False
        self.shield_active = False
        self.shield_hp = 0.0
        self.shield_max = 0.0

        self.charge_target: pygame.Vector2 | None = None
        self.charge_speed = 0.0
        self.laser_angle = 0.0
        self.laser_sweep_dir = 1

        self.is_dead = False
        self.death_processed = False
        self.hit_flash = Timer()
        self.spawn_anim = Timer()
        self.spawn_anim.start(0.6)

        self.attack_pool = (
            [BossPhase.SPREAD_BARRAGE, BossPhase.CHARGE, BossPhase.SUMMON]
            if mini
            else [
                BossPhase.SPREAD_BARRAGE,
                BossPhase.LASER_SWEEP,
                BossPhase.CHARGE,
                BossPhase.SHOCKWAVE,
                BossPhase.SUMMON,
                BossPhase.SHIELD,
            ]
        )

    def health_ratio(self) -> float:
        return clamp(self.health / self.max_health, 0, 1) if self.max_health else 0

    def take_damage(self, amount: float) -> float:
        if self.shield_active and self.shield_hp > 0:
            absorbed = min(self.shield_hp, amount)
            self.shield_hp -= absorbed
            amount -= absorbed
            if self.shield_hp <= 0:
                self.shield_active = False
        dealt = min(self.health, amount)
        self.health -= amount
        self.hit_flash.start(0.08)
        if self.health <= 0 and not self.is_dead:
            self.is_dead = True
        return dealt

    def rect(self) -> pygame.Rect:
        r = self.radius
        return pygame.Rect(self.pos.x - r, self.pos.y - r, r * 2, r * 2)

    # -- main update ------------------------------------------------------
    def update(self, dt: float, player_pos: pygame.Vector2, world_w: int, world_h: int) -> BossEvents:
        events = BossEvents()
        self.hit_flash.update(dt)
        self.spawn_anim.update(dt)

        if not self.enraged and self.health_ratio() <= 0.3:
            self.enraged = True
            events.enraged_this_frame = True

        speed_mult = 1.5 if self.enraged else 1.0
        to_player = player_pos - self.pos
        dist = to_player.length()
        direction = to_player.normalize() if dist > 1 else pygame.Vector2(0, -1)

        if self.phase == BossPhase.APPROACH:
            target_dist = 260
            if dist > target_dist:
                self.vel = direction * self.speed * speed_mult
            else:
                self.vel *= 0.9
            if self.phase_timer.update(dt):
                self._pick_next_phase()

        elif self.phase == BossPhase.SPREAD_BARRAGE:
            self.vel *= 0.94
            if self.phase_timer.update(dt):
                self._pick_next_phase()
            else:
                if not hasattr(self, "_barrage_timer"):
                    self._barrage_timer = Timer()
                    self._barrage_timer.start(0.16)
                if self._barrage_timer.update(dt):
                    self._barrage_timer.start(0.16 if not self.enraged else 0.1)
                    count = 10 if not self.mini else 6
                    base = direction.angle_to(pygame.Vector2(1, 0))
                    for i in range(count):
                        ang = (360 / count) * i
                        vel = pygame.Vector2(1, 0).rotate(-base + ang) * (300 if not self.mini else 260)
                        events.bullets.append(
                            Bullet(
                                pos=pygame.Vector2(self.pos), vel=vel, damage=self.damage * 0.5,
                                owner="enemy", radius=6, color=Color.NEON_MAGENTA,
                                sprite_key="spaceMissiles_013", sprite_size=(9, 20),
                            )
                        )

        elif self.phase == BossPhase.LASER_SWEEP:
            self.vel *= 0.9
            if not hasattr(self, "_laser_fire_timer"):
                self._laser_fire_timer = Timer()
                self._laser_fire_timer.start(0.05)
                self.laser_angle = direction.angle_to(pygame.Vector2(1, 0)) - 50
                self.laser_sweep_dir = random.choice([-1, 1])
            if self.phase_timer.update(dt):
                self._pick_next_phase()
                del self._laser_fire_timer
            else:
                self.laser_angle += self.laser_sweep_dir * 55 * dt
                if self._laser_fire_timer.update(dt):
                    self._laser_fire_timer.start(0.045)
                    vel = pygame.Vector2(1, 0).rotate(-self.laser_angle) * 560
                    events.bullets.append(
                        Bullet(
                            pos=pygame.Vector2(self.pos), vel=vel, damage=self.damage * 0.35,
                            owner="enemy", radius=5, color=Color.NEON_RED,
                            sprite_key="spaceMissiles_037", sprite_size=(6, 26), lifetime=1.0,
                        )
                    )

        elif self.phase == BossPhase.CHARGE:
            if self.charge_target is None:
                self.charge_target = pygame.Vector2(player_pos)
                self.charge_speed = 0
                events.charge_started = True
            self.charge_speed = min(self.charge_speed + 1400 * dt, 900 * speed_mult)
            to_target = self.charge_target - self.pos
            if to_target.length() > 4:
                self.vel = to_target.normalize() * self.charge_speed
            if to_target.length() < 30 or self.phase_timer.update(dt):
                self.charge_target = None
                self._pick_next_phase()

        elif self.phase == BossPhase.SHOCKWAVE:
            self.vel *= 0.8
            if not hasattr(self, "_shockwave_fired"):
                self._shockwave_fired = True
                events.shockwave_triggered = True
                count = 16
                for i in range(count):
                    ang = (360 / count) * i
                    vel = pygame.Vector2(1, 0).rotate(ang) * 260
                    events.bullets.append(
                        Bullet(
                            pos=pygame.Vector2(self.pos), vel=vel, damage=self.damage * 0.4,
                            owner="enemy", radius=6, color=Color.NEON_ORANGE,
                            sprite_key="spaceMissiles_025", sprite_size=(9, 20),
                        )
                    )
            if self.phase_timer.update(dt):
                del self._shockwave_fired
                self._pick_next_phase()

        elif self.phase == BossPhase.SUMMON:
            self.vel *= 0.85
            if not hasattr(self, "_summoned"):
                self._summoned = True
                events.summon_requests = 2 if not self.mini else 1
            if self.phase_timer.update(dt):
                del self._summoned
                self._pick_next_phase()

        elif self.phase == BossPhase.SHIELD:
            self.vel *= 0.9
            if not self.shield_active and not hasattr(self, "_shield_started"):
                self._shield_started = True
                self.shield_active = True
                self.shield_max = self.max_health * 0.2
                self.shield_hp = self.shield_max
            if self.phase_timer.update(dt) or self.shield_hp <= 0:
                self.shield_active = False
                if hasattr(self, "_shield_started"):
                    del self._shield_started
                self._pick_next_phase()

        elif self.phase == BossPhase.COOLDOWN:
            self.vel *= 0.92
            if self.phase_timer.update(dt):
                self._pick_next_phase()

        self.pos += self.vel * dt
        self.pos.x = clamp(self.pos.x, self.radius, world_w - self.radius)
        self.pos.y = clamp(self.pos.y, self.radius, world_h - self.radius)

        if to_player.length_squared() > 1 and self.phase not in (BossPhase.CHARGE,):
            target_angle = -direction.angle_to(pygame.Vector2(1, 0)) - 90
            self.angle = target_angle

        return events

    def _pick_next_phase(self) -> None:
        self.phase = BossPhase.COOLDOWN if self.phase != BossPhase.COOLDOWN else random.choice(self.attack_pool)
        if self.phase == BossPhase.COOLDOWN:
            self.phase_timer.start(random.uniform(0.6, 1.1))
            return
        durations = {
            BossPhase.SPREAD_BARRAGE: 2.4,
            BossPhase.LASER_SWEEP: 2.6,
            BossPhase.CHARGE: 1.6,
            BossPhase.SHOCKWAVE: 0.5,
            BossPhase.SUMMON: 0.8,
            BossPhase.SHIELD: 4.0,
        }
        self.phase_timer.start(durations.get(self.phase, 2.0))
