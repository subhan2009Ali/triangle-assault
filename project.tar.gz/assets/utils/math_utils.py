"""
utils/math_utils.py
--------------------
Small, dependency-free math helpers shared across the codebase.
Kept framework-agnostic (plain floats/tuples) except where a
pygame.Vector2 makes the call site meaningfully cleaner.
"""
from __future__ import annotations

import math
import random
from typing import Tuple

import pygame

Vec2 = pygame.Vector2


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def lerp_angle(a: float, b: float, t: float) -> float:
    """Shortest-path angle interpolation, degrees in, degrees out."""
    diff = (b - a + 180) % 360 - 180
    return a + diff * t


def move_towards(current: float, target: float, max_delta: float) -> float:
    if abs(target - current) <= max_delta:
        return target
    return current + max_delta * (1 if target > current else -1)


def angle_to(origin: Vec2, target: Vec2) -> float:
    """Degrees, 0 = pointing along +X, matches pygame rotate() convention
    once negated (see Player rotation code)."""
    delta = target - origin
    return math.degrees(math.atan2(delta.y, delta.x))


def distance(a: Vec2, b: Vec2) -> float:
    return a.distance_to(b)


def random_point_on_edge(edge, width: int, height: int, margin: int = 60) -> Vec2:
    """Return a random spawn point just outside the given screen edge."""
    from constants import SpawnEdge  # local import avoids circular import

    if edge == SpawnEdge.TOP:
        return Vec2(random.uniform(0, width), -margin)
    if edge == SpawnEdge.BOTTOM:
        return Vec2(random.uniform(0, width), height + margin)
    if edge == SpawnEdge.LEFT:
        return Vec2(-margin, random.uniform(0, height))
    if edge == SpawnEdge.RIGHT:
        return Vec2(width + margin, random.uniform(0, height))
    if edge == SpawnEdge.TOP_LEFT:
        return Vec2(-margin, -margin)
    if edge == SpawnEdge.TOP_RIGHT:
        return Vec2(width + margin, -margin)
    if edge == SpawnEdge.BOTTOM_LEFT:
        return Vec2(-margin, height + margin)
    return Vec2(width + margin, height + margin)


def random_unit_vector() -> Vec2:
    ang = random.uniform(0, math.tau)
    return Vec2(math.cos(ang), math.sin(ang))


def ease_out_cubic(t: float) -> float:
    t = clamp(t, 0.0, 1.0)
    return 1 - (1 - t) ** 3


def ease_out_back(t: float) -> float:
    c1 = 1.70158
    c3 = c1 + 1
    t = clamp(t, 0.0, 1.0)
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


def format_number(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)
