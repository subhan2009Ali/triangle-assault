"""
utils/timer.py
---------------
Tiny reusable countdown/cooldown timer. Used everywhere we need
"has N seconds passed" logic (weapon cooldowns, power-up durations,
invincibility frames, wave intermissions, etc.) without repeating
the same bookkeeping in every class.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Timer:
    duration: float = 0.0
    time_left: float = 0.0

    def start(self, duration: float | None = None) -> None:
        self.duration = duration if duration is not None else self.duration
        self.time_left = self.duration

    def update(self, dt: float) -> bool:
        """Advance the timer. Returns True the frame it finishes."""
        if self.time_left <= 0:
            return False
        self.time_left -= dt
        if self.time_left <= 0:
            self.time_left = 0
            return True
        return False

    @property
    def active(self) -> bool:
        return self.time_left > 0

    @property
    def progress(self) -> float:
        """0 -> just started, 1 -> finished."""
        if self.duration <= 0:
            return 1.0
        return 1.0 - (self.time_left / self.duration)

    @property
    def remaining_ratio(self) -> float:
        if self.duration <= 0:
            return 0.0
        return self.time_left / self.duration
