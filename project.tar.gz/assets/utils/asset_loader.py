"""
utils/asset_loader.py
----------------------
Centralized AssetManager.

Design goals (per project brief):
  * Never hard-code asset file names anywhere else in the codebase --
    other modules ask for a *logical* key ("player_ship", "laser_fire")
    and this manager resolves it to a file, or to a generated
    placeholder if the file is missing.
  * Loading new assets should only ever require dropping a file into
    assets/images or assets/sounds (and, optionally, adding a line to
    the lookup tables below) -- no code changes elsewhere.
  * Everything is cached: an image/sound is only ever loaded from disk
    once per (path, size) combination.

If an asset is missing, a clearly-marked placeholder (a magenta/black
checker square for images, a short silent buffer for sounds) is
generated instead of crashing, so the game always keeps running.
"""
from __future__ import annotations

import os
from typing import Optional

import pygame

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMAGES_DIR = os.path.join(BASE_DIR, "assets", "images")
SOUNDS_DIR = os.path.join(BASE_DIR, "assets", "sounds")
FONTS_DIR = os.path.join(BASE_DIR, "assets", "fonts")


def _placeholder_surface(size: tuple[int, int] = (48, 48)) -> pygame.Surface:
    w, h = size
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    tile = max(4, min(w, h) // 6)
    magenta = (230, 30, 200, 255)
    black = (20, 20, 20, 255)
    for y in range(0, h, tile):
        for x in range(0, w, tile):
            color = magenta if ((x // tile) + (y // tile)) % 2 == 0 else black
            pygame.draw.rect(surf, color, (x, y, tile, tile))
    pygame.draw.rect(surf, (255, 255, 255, 255), surf.get_rect(), 2)
    return surf


class AssetManager:
    """Loads and caches images and sounds, indexed by directory."""

    def __init__(self) -> None:
        self._image_cache: dict[str, pygame.Surface] = {}
        self._scaled_cache: dict[tuple[str, int, int], pygame.Surface] = {}
        self._sound_cache: dict[str, pygame.mixer.Sound] = {}
        self._font_cache: dict[tuple[Optional[str], int], pygame.font.Font] = {}

        self._image_index = self._index_directory(IMAGES_DIR, {".png", ".jpg", ".jpeg"})
        self._sound_index = self._index_directory(SOUNDS_DIR, {".ogg", ".wav"})

    # -- indexing -----------------------------------------------------
    @staticmethod
    def _index_directory(root: str, extensions: set[str]) -> dict[str, str]:
        """Recursively map `stem_lowercase -> absolute_path` for every
        matching file under `root`, if it exists."""
        index: dict[str, str] = {}
        if not os.path.isdir(root):
            return index
        for dirpath, _dirs, files in os.walk(root):
            for fname in files:
                stem, ext = os.path.splitext(fname)
                if ext.lower() in extensions:
                    index[stem.lower()] = os.path.join(dirpath, fname)
        return index

    # -- images ---------------------------------------------------------
    def get_image(self, key: str, size: Optional[tuple[int, int]] = None) -> pygame.Surface:
        """Fetch an image by logical key (case-insensitive filename stem,
        e.g. 'spaceShips_001'). Falls back to a placeholder if missing."""
        cache_key = key.lower()
        if cache_key not in self._image_cache:
            path = self._image_index.get(cache_key)
            if path:
                try:
                    self._image_cache[cache_key] = pygame.image.load(path).convert_alpha()
                except pygame.error:
                    self._image_cache[cache_key] = _placeholder_surface()
            else:
                self._image_cache[cache_key] = _placeholder_surface()

        base = self._image_cache[cache_key]
        if size is None:
            return base

        scale_key = (cache_key, size[0], size[1])
        if scale_key not in self._scaled_cache:
            self._scaled_cache[scale_key] = pygame.transform.smoothscale(base, size)
        return self._scaled_cache[scale_key]

    def has_image(self, key: str) -> bool:
        return key.lower() in self._image_index

    # -- sounds -----------------------------------------------------------
    def get_sound(self, key: str) -> Optional[pygame.mixer.Sound]:
        cache_key = key.lower()
        if cache_key in self._sound_cache:
            return self._sound_cache[cache_key]
        path = self._sound_index.get(cache_key)
        if not path or not pygame.mixer.get_init():
            return None
        try:
            snd = pygame.mixer.Sound(path)
        except pygame.error:
            return None
        self._sound_cache[cache_key] = snd
        return snd

    def has_sound(self, key: str) -> bool:
        return key.lower() in self._sound_index

    def get_music_path(self, key: str) -> Optional[str]:
        return self._sound_index.get(key.lower())

    # -- fonts --------------------------------------------------------
    def get_font(self, size: int, name: Optional[str] = None) -> pygame.font.Font:
        cache_key = (name, size)
        if cache_key not in self._font_cache:
            path = None
            if name:
                for ext in (".ttf", ".otf"):
                    candidate = os.path.join(FONTS_DIR, f"{name}{ext}")
                    if os.path.isfile(candidate):
                        path = candidate
                        break
            if path:
                self._font_cache[cache_key] = pygame.font.Font(path, size)
            else:
                self._font_cache[cache_key] = pygame.font.SysFont(
                    "arial,helvetica,verdana", size, bold=True
                )
        return self._font_cache[cache_key]


# Module-level singleton -- most modules just `from utils.asset_loader import assets`.
# Building the file index doesn't touch pygame at all (just os.walk), so it's
# safe to construct immediately at import time; only get_image/get_sound/get_font
# (called later, after pygame.init()) actually touch the pygame API.
assets: AssetManager = AssetManager()


def init_asset_manager() -> AssetManager:
    """The singleton is already built at import time (see `assets`
    above); this is kept as an explicit call site in main.py for
    readability/backwards-compat and simply returns it unchanged so
    every module's `from utils.asset_loader import assets` reference
    stays valid."""
    return assets
