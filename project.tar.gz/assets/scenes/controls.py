"""
scenes/controls.py
-------------------
Static controls reference screen.
"""
from __future__ import annotations

import pygame

from constants import Color
from scenes.base import Scene
from systems.ui import Button, draw_panel, draw_text

CONTROLS = [
    ("Move", "Move mouse - ship eases toward the cursor"),
    ("Aim", "Ship automatically faces the cursor"),
    ("Fire", "Hold Left Mouse Button"),
    ("Switch Weapon", "Q / E"),
    ("Pause", "ESC"),
    ("Mute", "M"),
]


class ControlsScene(Scene):
    def on_enter(self, **kwargs) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        self.back_button = Button(pygame.Rect(w / 2 - 110, h - 90, 220, 50), "BACK", callback=lambda: self.manager.pop())

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.manager.pop()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.back_button.handle_click(event.pos)

    def update(self, dt: float) -> None:
        self.back_button.update(dt, pygame.mouse.get_pos())

    def draw(self, surface: pygame.Surface) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((6, 8, 16, 235))
        surface.blit(overlay, (0, 0))

        draw_text(surface, "CONTROLS", (w / 2, 90), size=38, color=Color.NEON_CYAN, align="center")

        panel = pygame.Rect(0, 0, 560, len(CONTROLS) * 48 + 30)
        panel.center = (w / 2, h / 2)
        draw_panel(surface, panel)
        y = panel.y + 24
        for action, desc in CONTROLS:
            draw_text(surface, action, (panel.x + 24, y), size=17, color=Color.NEON_YELLOW)
            draw_text(surface, desc, (panel.right - 24, y), size=15, color=Color.WHITE, align="topright")
            y += 48

        self.back_button.draw(surface)
