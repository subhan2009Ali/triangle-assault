"""
scenes/pause.py
----------------
Pause overlay pushed on top of gameplay. Because SceneManager draws
the whole stack, the paused game freezes visually behind a dark
overlay while this scene handles input.
"""
from __future__ import annotations

import pygame

from constants import Color
from scenes.base import Scene
from systems.ui import Button, draw_panel, draw_text


class PauseScene(Scene):
    def on_enter(self, **kwargs) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        cx, cy = w / 2, h / 2
        btn_w, btn_h, gap = 260, 52, 14
        labels = [
            ("RESUME", self._resume),
            ("SETTINGS", self._settings),
            ("QUIT TO MENU", self._quit),
        ]
        start_y = cy - (btn_h * len(labels) + gap * (len(labels) - 1)) / 2
        self.buttons = [
            Button(pygame.Rect(cx - btn_w / 2, start_y + i * (btn_h + gap), btn_w, btn_h), label, callback=cb)
            for i, (label, cb) in enumerate(labels)
        ]
        self.overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        self.overlay.fill((6, 8, 16, 165))

    def _resume(self) -> None:
        self.manager.pop()

    def _settings(self) -> None:
        from scenes.settings import SettingsScene
        self.manager.push(SettingsScene(self.ctx))

    def _quit(self) -> None:
        from scenes.menu import MenuScene
        self.manager.switch(MenuScene(self.ctx))

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self._resume()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                b.handle_click(event.pos)

    def update(self, dt: float) -> None:
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.update(dt, mouse)

    def draw(self, surface: pygame.Surface) -> None:
        surface.blit(self.overlay, (0, 0))
        draw_text(surface, "PAUSED", (self.ctx.world_w / 2, self.ctx.world_h / 2 - 160), size=44, color=Color.WHITE, align="center")
        for b in self.buttons:
            b.draw(surface)
