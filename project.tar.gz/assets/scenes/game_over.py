"""
scenes/game_over.py
--------------------
Shown when the player runs out of lives. Displays run stats (score,
wave reached, coins earned) plus a new-high-score callout, and offers
Retry / Main Menu.
"""
from __future__ import annotations

import pygame

from constants import Color
from scenes.base import Scene
from systems.ui import Button, draw_panel, draw_text


class GameOverScene(Scene):
    def on_enter(self, **kwargs) -> None:
        ctx = self.ctx
        rs = ctx.run_state
        self.score = rs.player.score if rs else 0
        self.wave = rs.wave_manager.wave_number if rs else 0
        self.coins = rs.player.coins if rs else 0
        self.is_new_high = self.score >= ctx.save_data.high_score and self.score > 0

        w, h = ctx.world_w, ctx.world_h
        cx, cy = w / 2, h / 2 + 120
        btn_w, btn_h, gap = 240, 54, 16
        self.buttons = [
            Button(pygame.Rect(cx - btn_w - gap / 2, cy, btn_w, btn_h), "RETRY", callback=self._retry),
            Button(pygame.Rect(cx + gap / 2, cy, btn_w, btn_h), "MAIN MENU", callback=self._menu),
        ]
        ctx.sound.play("lowDown", volume=0.6)

    def _retry(self) -> None:
        from scenes.gameplay import GameplayScene
        self.manager.switch(GameplayScene(self.ctx), new_run=True)

    def _menu(self) -> None:
        from scenes.menu import MenuScene
        self.manager.switch(MenuScene(self.ctx))

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                b.handle_click(event.pos)

    def update(self, dt: float) -> None:
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.update(dt, mouse)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        surface.fill(Color.BG_TOP)
        draw_text(surface, "GAME OVER", (w / 2, h / 2 - 180), size=54, color=Color.NEON_RED, align="center")
        if self.is_new_high:
            draw_text(surface, "NEW HIGH SCORE!", (w / 2, h / 2 - 120), size=22, color=Color.NEON_YELLOW, align="center")

        panel = pygame.Rect(0, 0, 420, 130)
        panel.center = (w / 2, h / 2 - 30)
        draw_panel(surface, panel)
        draw_text(surface, f"Score: {self.score}", (panel.centerx, panel.y + 20), size=20, align="center")
        draw_text(surface, f"Wave Reached: {self.wave}", (panel.centerx, panel.y + 55), size=18, color=Color.NEON_CYAN, align="center")
        draw_text(surface, f"Coins Earned: {self.coins}", (panel.centerx, panel.y + 88), size=18, color=Color.COIN, align="center")

        for b in self.buttons:
            b.draw(surface)
