"""
scenes/settings.py
-------------------
Settings screen: video (fullscreen, vsync, fps limit), audio (music /
sfx volume sliders, mute), and gameplay (difficulty, screen shake,
damage numbers). Changes are written into ctx.config live and
persisted to disk on exit via save_system.
"""
from __future__ import annotations

import pygame

from config import DIFFICULTIES
from constants import Color
from scenes.base import Scene
from systems.save_system import save_game
from systems.ui import Button, Slider, draw_panel, draw_text


class SettingsScene(Scene):
    def on_enter(self, **kwargs) -> None:
        ctx = self.ctx
        w, h = ctx.world_w, ctx.world_h
        cfg = ctx.config

        left_x = w / 2 - 220
        slider_w = 300

        self.music_slider = Slider(pygame.Rect(left_x, 190, slider_w, 4), cfg.music_volume, "MUSIC VOLUME", on_change=self._set_music)
        self.sfx_slider = Slider(pygame.Rect(left_x, 250, slider_w, 4), cfg.sfx_volume, "SFX VOLUME", on_change=self._set_sfx)

        self.toggle_buttons = []
        by = 320
        self._add_toggle(left_x, by, "FULLSCREEN", lambda: cfg.fullscreen, self._toggle_fullscreen)
        self._add_toggle(left_x, by + 56, "SCREEN SHAKE", lambda: cfg.screen_shake_enabled, self._toggle_shake)
        self._add_toggle(left_x, by + 112, "DAMAGE NUMBERS", lambda: cfg.damage_numbers_enabled, self._toggle_dmg_numbers)
        self._add_toggle(left_x, by + 168, "SHOW FPS", lambda: cfg.show_fps, self._toggle_fps)
        self._add_toggle(left_x, by + 224, "MUTE ALL", lambda: cfg.muted, self._toggle_mute)

        self.difficulty_index = DIFFICULTIES.index(cfg.difficulty) if cfg.difficulty in DIFFICULTIES else 1
        self.difficulty_button = Button(pygame.Rect(left_x, by + 280, 300, 44), self._difficulty_label(), callback=self._cycle_difficulty)

        self.back_button = Button(pygame.Rect(w / 2 - 110, h - 90, 220, 50), "BACK", callback=self._back)

    def _difficulty_label(self) -> str:
        return f"DIFFICULTY: {DIFFICULTIES[self.difficulty_index].upper()}"

    def _cycle_difficulty(self) -> None:
        self.difficulty_index = (self.difficulty_index + 1) % len(DIFFICULTIES)
        self.ctx.config.difficulty = DIFFICULTIES[self.difficulty_index]
        self.difficulty_button.label = self._difficulty_label()

    def _add_toggle(self, x, y, label, getter, callback) -> None:
        btn = Button(pygame.Rect(x, y, 300, 44), f"{label}: {'ON' if getter() else 'OFF'}", callback=None)

        def on_click(b=btn, label=label, getter=getter, callback=callback) -> None:
            callback()
            b.label = f"{label}: {'ON' if getter() else 'OFF'}"

        btn.callback = on_click
        self.toggle_buttons.append(btn)

    def _toggle_fullscreen(self) -> None:
        self.ctx.config.fullscreen = not self.ctx.config.fullscreen
        flags = pygame.FULLSCREEN | pygame.SCALED if self.ctx.config.fullscreen else pygame.RESIZABLE
        try:
            pygame.display.set_mode((self.ctx.world_w, self.ctx.world_h), flags)
        except pygame.error:
            pass

    def _toggle_shake(self) -> None:
        self.ctx.config.screen_shake_enabled = not self.ctx.config.screen_shake_enabled

    def _toggle_dmg_numbers(self) -> None:
        self.ctx.config.damage_numbers_enabled = not self.ctx.config.damage_numbers_enabled

    def _toggle_fps(self) -> None:
        self.ctx.config.show_fps = not self.ctx.config.show_fps

    def _toggle_mute(self) -> None:
        self.ctx.sound.toggle_mute()

    def _set_music(self, v: float) -> None:
        self.ctx.config.music_volume = v
        self.ctx.sound.refresh_music_volume()

    def _set_sfx(self, v: float) -> None:
        self.ctx.config.sfx_volume = v

    def _back(self) -> None:
        self.ctx.save_data.config = self.ctx.config
        save_game(self.ctx.save_data)
        self.manager.pop()

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self._back()
            return
        self.music_slider.handle_event(event)
        self.sfx_slider.handle_event(event)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.toggle_buttons + [self.difficulty_button, self.back_button]:
                b.handle_click(event.pos)

    def update(self, dt: float) -> None:
        mouse = pygame.mouse.get_pos()
        for b in self.toggle_buttons + [self.difficulty_button, self.back_button]:
            b.update(dt, mouse)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((6, 8, 16, 235))
        surface.blit(overlay, (0, 0))

        draw_text(surface, "SETTINGS", (w / 2, 90), size=40, color=Color.NEON_CYAN, align="center")

        self.music_slider.draw(surface)
        self.sfx_slider.draw(surface)
        for b in self.toggle_buttons:
            b.draw(surface)
        self.difficulty_button.draw(surface)
        self.back_button.draw(surface)
