"""
scenes/base.py
---------------
Defines the Scene interface every screen (menu, gameplay, shop, ...)
implements, plus the AppContext bundle that's threaded through all of
them (screen surface, config, save data, sound manager, asset
manager). Keeping shared state in one small context object avoids a
tangle of globals while still letting every scene reach what it needs.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import pygame

from config import Config
from systems.save_system import SaveData
from systems.sound import SoundManager


@dataclass
class AppContext:
    screen: pygame.Surface
    config: Config
    save_data: SaveData
    sound: SoundManager
    clock: pygame.time.Clock
    world_w: int
    world_h: int

    # transient per-run state shared between gameplay <-> shop <-> game_over
    run_state: Optional[object] = None


class Scene:
    """Base class for all scenes. `manager` is set by SceneManager on push."""

    def __init__(self, ctx: AppContext) -> None:
        self.ctx = ctx
        self.manager: Optional["SceneManager"] = None

    def on_enter(self, **kwargs) -> None:
        pass

    def on_exit(self) -> None:
        pass

    def handle_event(self, event: pygame.event.Event) -> None:
        pass

    def update(self, dt: float) -> None:
        pass

    def draw(self, surface: pygame.Surface) -> None:
        pass


class SceneManager:
    """A small stack-based scene manager. Pushing keeps the previous
    scene alive underneath (used for the pause overlay); switching
    replaces the top entirely (used for menu <-> gameplay)."""

    def __init__(self, ctx: AppContext) -> None:
        self.ctx = ctx
        self.stack: list[Scene] = []

    @property
    def current(self) -> Optional[Scene]:
        return self.stack[-1] if self.stack else None

    def switch(self, scene: Scene, **kwargs) -> None:
        while self.stack:
            self.stack.pop().on_exit()
        scene.manager = self
        self.stack.append(scene)
        scene.on_enter(**kwargs)

    def push(self, scene: Scene, **kwargs) -> None:
        scene.manager = self
        self.stack.append(scene)
        scene.on_enter(**kwargs)

    def pop(self) -> None:
        if self.stack:
            self.stack.pop().on_exit()

    def handle_event(self, event: pygame.event.Event) -> None:
        if self.current:
            self.current.handle_event(event)

    def update(self, dt: float) -> None:
        if self.current:
            self.current.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        # draw the whole stack so pause overlays render gameplay behind them
        for scene in self.stack:
            scene.draw(surface)
