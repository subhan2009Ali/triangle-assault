"""
scenes/credits.py
------------------
Simple credits screen crediting the Kenney.nl asset packs used for art
and audio, plus the pygame-ce project.
"""
from __future__ import annotations

import pygame

from constants import Color
from scenes.base import Scene
from systems.ui import Button, draw_panel, draw_text

CREDITS_LINES = [
    ("TRIANGLE ASSAULT", 30, Color.NEON_CYAN),
    ("", 12, Color.WHITE),
    ("Built with Python & pygame-ce", 16, Color.WHITE),
    ("", 12, Color.WHITE),
    ("Art & Sound", 20, Color.NEON_YELLOW),
    ("Space Shooter Extension - Kenney.nl", 15, Color.UI_DIM),
    ("Digital Audio - Kenney.nl", 15, Color.UI_DIM),
    ("Sci-Fi Sounds - Kenney.nl", 15, Color.UI_DIM),
    ("All assets used under Kenney's CC0 license", 13, Color.UI_DIM),
    ("", 16, Color.WHITE),
    ("Engine", 20, Color.NEON_YELLOW),
    ("pygame-ce - community fork of pygame", 15, Color.UI_DIM),
    ("", 20, Color.WHITE),
    ("Thanks for playing!", 20, Color.NEON_GREEN),
]


class CreditsScene(Scene):
    def on_enter(self, **kwargs) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        self.back_button = Button(pygame.Rect(w / 2 - 110, h - 90, 220, 50), "BACK", callback=lambda: self.manager.pop())

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.manager.pop()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.back_button.handle_click(event.pos)

    def update(self, dt: float) -> None:
        self.back_button.update(dt, pygame.mouse.get_pos())

    def draw(self, surface: pygame.Surface) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((6, 8, 16, 235))
        surface.blit(overlay, (0, 0))

        y = 90
        for text, size, color in CREDITS_LINES:
            if text:
                draw_text(surface, text, (w / 2, y), size=size, color=color, align="center")
            y += size + 14

        self.back_button.draw(surface)
