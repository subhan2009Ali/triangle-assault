"""
scenes/shop.py
---------------
Between-wave upgrade shop. Pushed automatically by GameplayScene at
the start of each intermission. Spending here is immediate and
persists into SaveData (permanent meta-progression), while weapon
unlocks purchased mid-run are also applied to the current player
instance right away.
"""
from __future__ import annotations

import pygame

from constants import Color, WeaponType
from entities.weapon import WEAPON_DEFS
from scenes.base import Scene
from systems.save_system import save_game
from systems.ui import Button, draw_bar, draw_panel, draw_text
from systems.upgrade_shop import (
    MAX_UPGRADE_LEVEL,
    UPGRADE_OPTIONS,
    WEAPON_UNLOCK_COSTS,
    purchase_upgrade,
    purchase_weapon,
    upgrade_cost,
)


class ShopScene(Scene):
    def on_enter(self, **kwargs) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        cols = 5
        card_w, card_h, gap = 190, 140, 14
        grid_w = cols * card_w + (cols - 1) * gap
        start_x = w / 2 - grid_w / 2
        start_y = 160

        self.upgrade_cards = []
        for i, option in enumerate(UPGRADE_OPTIONS):
            col = i % cols
            row = i // cols
            rect = pygame.Rect(start_x + col * (card_w + gap), start_y + row * (card_h + gap), card_w, card_h)
            self.upgrade_cards.append((option, rect))

        weapon_y = start_y + 2 * (card_h + gap) + 30
        self.weapon_buttons = []
        locked = [wt for wt in WeaponType if wt not in self.ctx.run_state.player.weapons and wt in WEAPON_UNLOCK_COSTS]
        for i, wt in enumerate(locked):
            rect = pygame.Rect(start_x + i * (card_w + gap), weapon_y, card_w, 70)
            self.weapon_buttons.append((wt, rect))

        self.continue_button = Button(pygame.Rect(w / 2 - 130, h - 76, 260, 52), "CONTINUE", callback=self._continue)
        self.flash_msg = ""
        self.flash_timer = 0.0

    def _continue(self) -> None:
        self.ctx.run_state.wave_manager.skip_intermission()
        self.manager.pop()

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self._continue()
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.continue_button.handle_click(event.pos)
            for option, rect in self.upgrade_cards:
                if rect.collidepoint(event.pos):
                    self._buy_upgrade(option)
            for wt, rect in self.weapon_buttons:
                if rect.collidepoint(event.pos):
                    self._buy_weapon(wt)

    def _buy_upgrade(self, option) -> None:
        ctx = self.ctx
        player = ctx.run_state.player
        upgrades, coins, success = purchase_upgrade(ctx.save_data.upgrades, option.key, player.coins)
        if success:
            ctx.save_data.upgrades = upgrades
            player.coins = coins
            self._apply_upgrade_live(option.key)
            ctx.sound.play(("powerUp7", "powerUp8"), volume=0.6)
            self.flash_msg = f"{option.label} upgraded!"
            self.flash_timer = 1.4
            save_game(ctx.save_data)
        else:
            ctx.sound.play("lowRandom", volume=0.4)

    def _apply_upgrade_live(self, key: str) -> None:
        """Immediately reflect a few key upgrades on the live player
        instance so the purchase feels impactful mid-run."""
        player = self.ctx.run_state.player
        if key == "max_health":
            player.max_health += 12
            player.health += 12
        elif key == "move_speed":
            player.max_speed += 18
        elif key == "shield_capacity":
            player.max_shield += 15
        elif key == "damage":
            player.damage_multiplier += 0.06
        elif key == "crit_chance":
            player.crit_bonus += 0.02
            for w in player.weapons.values():
                w.crit_chance += 0.02
        elif key == "xp_gain":
            player.xp_gain_mult += 0.08
        elif key == "coin_multiplier":
            player.coin_mult += 0.08
        elif key == "energy_regen":
            player.energy_regen_bonus += 1
        elif key == "luck":
            player.luck += 1

    def _buy_weapon(self, weapon_type: WeaponType) -> None:
        ctx = self.ctx
        player = ctx.run_state.player
        unlocked, coins, success = purchase_weapon(ctx.save_data.unlocked_weapons, weapon_type, player.coins)
        if success:
            ctx.save_data.unlocked_weapons = unlocked
            player.coins = coins
            player.apply_weapon_pickup(weapon_type)
            ctx.sound.play(("powerUp9", "powerUp10"), volume=0.6)
            self.flash_msg = f"{WEAPON_DEFS[weapon_type].name} unlocked!"
            self.flash_timer = 1.4
            save_game(ctx.save_data)
            self.on_enter()  # rebuild weapon button list
        else:
            ctx.sound.play("lowRandom", volume=0.4)

    def update(self, dt: float) -> None:
        mouse = pygame.mouse.get_pos()
        self.continue_button.update(dt, mouse)
        if self.flash_timer > 0:
            self.flash_timer -= dt

    def draw(self, surface: pygame.Surface) -> None:
        ctx = self.ctx
        w, h = ctx.world_w, ctx.world_h
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((6, 8, 16, 232))
        surface.blit(overlay, (0, 0))

        draw_text(surface, "UPGRADE SHOP", (w / 2, 56), size=38, color=Color.NEON_CYAN, align="center")
        player = ctx.run_state.player
        draw_text(surface, f"Coins: {player.coins}", (w / 2, 100), size=20, color=Color.COIN, align="center")

        for option, rect in self.upgrade_cards:
            level = getattr(ctx.save_data.upgrades, option.key)
            maxed = level >= MAX_UPGRADE_LEVEL
            cost = upgrade_cost(option, level) if not maxed else 0
            affordable = maxed or player.coins >= cost
            draw_panel(surface, rect, color=Color.PANEL_LIGHT if affordable else Color.PANEL, border_color=Color.NEON_CYAN if affordable and not maxed else Color.UI_DIM)
            draw_text(surface, option.label, (rect.centerx, rect.y + 14), size=15, align="center")
            draw_text(surface, option.description, (rect.centerx, rect.y + 40), size=10, color=Color.UI_DIM, align="center")
            draw_bar(surface, pygame.Rect(rect.x + 14, rect.y + 66, rect.width - 28, 8), level / MAX_UPGRADE_LEVEL, Color.XP)
            draw_text(surface, f"Lv {level}/{MAX_UPGRADE_LEVEL}", (rect.centerx, rect.y + 80), size=11, color=Color.UI_DIM, align="center")
            cost_text = "MAXED" if maxed else f"{cost} coins"
            draw_text(surface, cost_text, (rect.centerx, rect.bottom - 22), size=13, color=Color.COIN if affordable else Color.UI_DIM, align="center")

        for wt, rect in self.weapon_buttons:
            cost = WEAPON_UNLOCK_COSTS[wt]
            affordable = player.coins >= cost
            wdef = WEAPON_DEFS[wt]
            draw_panel(surface, rect, color=Color.PANEL_LIGHT if affordable else Color.PANEL, border_color=wdef.color)
            draw_text(surface, wdef.name.upper(), (rect.centerx, rect.y + 14), size=14, color=wdef.color, align="center")
            draw_text(surface, wdef.description, (rect.centerx, rect.y + 36), size=9, color=Color.UI_DIM, align="center")
            draw_text(surface, f"{cost} coins", (rect.centerx, rect.bottom - 16), size=12, color=Color.COIN if affordable else Color.UI_DIM, align="center")

        if self.flash_timer > 0:
            draw_text(surface, self.flash_msg, (w / 2, h - 130), size=16, color=Color.NEON_GREEN, align="center")

        self.continue_button.draw(surface)
