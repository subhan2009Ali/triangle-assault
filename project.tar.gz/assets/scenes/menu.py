"""
scenes/menu.py
---------------
Main menu: Play / Settings / Controls / Credits / Quit, with an
animated starfield + drifting ship backdrop so the menu doesn't feel
static.
"""
from __future__ import annotations

import math
import random

import pygame

from constants import Color, GAME_TITLE
from scenes.base import Scene
from systems.ui import Button, draw_panel, draw_text, draw_vertical_gradient
from utils.asset_loader import assets


class MenuScene(Scene):
    def on_enter(self, **kwargs) -> None:
        self.ctx.run_state = None
        w, h = self.ctx.world_w, self.ctx.world_h
        self.stars = [
            (pygame.Vector2(random.uniform(0, w), random.uniform(0, h)), random.uniform(10, 60), random.uniform(1, 2.5))
            for _ in range(120)
        ]
        self.t = 0.0
        cx, cy = w / 2, h / 2 + 40
        btn_w, btn_h, gap = 280, 56, 16
        start_y = cy - (btn_h * 4 + gap * 3) / 2 + 40
        self.buttons = [
            Button(pygame.Rect(cx - btn_w / 2, start_y + i * (btn_h + gap), btn_w, btn_h), label, callback=cb)
            for i, (label, cb) in enumerate(
                [
                    ("PLAY", self._play),
                    ("SETTINGS", self._settings),
                    ("CONTROLS", self._controls),
                    ("CREDITS", self._credits),
                ]
            )
        ]
        self.high_score = self.ctx.save_data.high_score

    def _play(self) -> None:
        from scenes.gameplay import GameplayScene
        self.manager.switch(GameplayScene(self.ctx), new_run=True)

    def _settings(self) -> None:
        from scenes.settings import SettingsScene
        self.manager.push(SettingsScene(self.ctx))

    def _controls(self) -> None:
        from scenes.controls import ControlsScene
        self.manager.push(ControlsScene(self.ctx))

    def _credits(self) -> None:
        from scenes.credits import CreditsScene
        self.manager.push(CreditsScene(self.ctx))

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                b.handle_click(event.pos)

    def update(self, dt: float) -> None:
        self.t += dt
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.update(dt, mouse)
        for pos, speed, _size in self.stars:
            pos.y += speed * dt
            if pos.y > self.ctx.world_h:
                pos.y = -4
                pos.x = random.uniform(0, self.ctx.world_w)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = self.ctx.world_w, self.ctx.world_h
        draw_vertical_gradient(surface, surface.get_rect(), Color.BG_TOP, Color.BG_BOTTOM)
        for pos, _speed, size in self.stars:
            b = 140 + int(60 * math.sin(self.t + pos.x))
            pygame.draw.circle(surface, (b, b, min(255, b + 30)), (int(pos.x), int(pos.y)), max(1, int(size)))

        ship_size = 120
        bob = math.sin(self.t * 1.4) * 10
        img = assets.get_image("spaceShips_001", (ship_size, ship_size))
        rect = img.get_rect(center=(w / 2, 190 + bob))
        surface.blit(img, rect)

        draw_text(surface, GAME_TITLE, (w / 2, 300), size=58, color=Color.NEON_CYAN, align="center")
        draw_text(surface, "A top-down arcade shooter", (w / 2, 350), size=16, color=Color.UI_DIM, align="center")

        for b in self.buttons:
            b.draw(surface)

        draw_text(surface, f"High Score: {self.high_score}", (w / 2, h - 34), size=15, color=Color.COIN, align="center")
