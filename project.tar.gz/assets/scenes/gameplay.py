"""
scenes/gameplay.py
-------------------
The core play scene: owns the live entity collections for a run
(player, enemies, boss, bullets, power-ups, particles) and drives the
per-frame update -> collide -> react -> draw loop. Wave progression is
delegated to WaveManager; the shop is a separate scene pushed
automatically at the start of each intermission.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

import pygame

from constants import (
    Color,
    EnemyType,
    Layer,
    PowerUpType,
    WeaponType,
)
from entities.bullet import BulletManager
from entities.boss import Boss, BossPhase
from entities.enemy import ENEMY_DEFS, Enemy
from entities.player import Player
from entities.powerup import POWERUP_DEFS, PowerUp, roll_drop, WEAPON_PICKUP_CHANCE
from entities.weapon import WEAPON_DEFS
from scenes.base import Scene
from systems import collision
from systems.camera import Camera
from systems.particles import ParticleSystem
from systems.save_system import save_game
from systems.ui import draw_bar, draw_panel, draw_text, font
from systems.wave_manager import WaveManager, WaveState
from utils.asset_loader import assets
from utils.math_utils import clamp, format_number

WEAPON_UNLOCK_ORDER = [WeaponType.SPREAD, WeaponType.SHOTGUN, WeaponType.LASER, WeaponType.MISSILE]


@dataclass
class Star:
    pos: pygame.Vector2
    speed: float
    size: float
    brightness: int


@dataclass
class RunState:
    player: Player
    wave_manager: WaveManager
    bullets: BulletManager = field(default_factory=BulletManager)
    enemies: list = field(default_factory=list)
    boss: object = None
    powerups: list = field(default_factory=list)
    particles: ParticleSystem = field(default_factory=ParticleSystem)
    camera: Camera = None
    stars: list = field(default_factory=list)
    shop_shown_this_intermission: bool = False
    boss_intro_timer: float = 0.0
    time_survived: float = 0.0
    game_over_processed: bool = False


class GameplayScene(Scene):
    def on_enter(self, new_run: bool = False, **kwargs) -> None:
        if new_run or self.ctx.run_state is None:
            self._start_new_run()
        self.mouse_down = False

    def _start_new_run(self) -> None:
        ctx = self.ctx
        player = Player(ctx.world_w, ctx.world_h, upgrades=ctx.save_data.upgrades)
        for wname in ctx.save_data.unlocked_weapons:
            try:
                player.unlock_weapon(WeaponType[wname])
            except KeyError:
                pass
        mods = ctx.config.difficulty_mods()
        wave_manager = WaveManager(ctx.world_w, ctx.world_h, mods)
        camera = Camera(ctx.world_w, ctx.world_h)
        stars = self._make_starfield(ctx.world_w, ctx.world_h)
        ctx.run_state = RunState(player=player, wave_manager=wave_manager, camera=camera, stars=stars)

    @staticmethod
    def _make_starfield(w: int, h: int) -> list:
        stars = []
        for _ in range(140):
            stars.append(
                Star(
                    pygame.Vector2(random.uniform(0, w), random.uniform(0, h)),
                    speed=random.uniform(12, 70),
                    size=random.uniform(1, 2.6),
                    brightness=random.randint(90, 220),
                )
            )
        return stars

    # -- events -------------------------------------------------------
    def handle_event(self, event: pygame.event.Event) -> None:
        rs: RunState = self.ctx.run_state
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                from scenes.pause import PauseScene
                self.manager.push(PauseScene(self.ctx))
            elif event.key == pygame.K_e:
                rs.player.switch_weapon(1)
            elif event.key == pygame.K_q:
                rs.player.switch_weapon(-1)
            elif event.key == pygame.K_m:
                self.ctx.sound.toggle_mute()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.mouse_down = True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.mouse_down = False

    # -- update ---------------------------------------------------------
    def update(self, dt: float) -> None:
        ctx = self.ctx
        rs: RunState = ctx.run_state
        if rs is None:
            return

        raw_dt = dt
        if rs.player.status.slow_motion.active:
            dt *= 0.45

        rs.time_survived += raw_dt
        mouse_pos = pygame.Vector2(pygame.mouse.get_pos())

        self._update_starfield(rs, raw_dt)

        player = rs.player
        player.update_movement(dt, mouse_pos)
        player.update_rotation(dt, mouse_pos)
        player.update_status(dt)

        if self.mouse_down and not player.is_dead:
            new_bullets = player.try_fire()
            if new_bullets:
                for b in new_bullets:
                    rs.bullets.add(b)
                ctx.sound.play(player.weapon.stats.sound_keys, volume=0.55)

        self._update_wave_and_spawns(rs, dt)
        self._update_enemies(rs, dt)
        self._update_boss(rs, dt)
        rs.bullets.update(dt, ctx.world_w, ctx.world_h, find_target=lambda p: self._nearest_enemy(rs, p))
        self._resolve_collisions(rs, dt)
        self._update_powerups(rs, dt)

        rs.particles.update(raw_dt)
        rs.camera.update(raw_dt, ctx.config.screen_shake_enabled)

        self._check_wave_transitions(rs)

        if player.is_dead and not rs.game_over_processed:
            self._handle_game_over(rs)

    def _update_starfield(self, rs: RunState, dt: float) -> None:
        for s in rs.stars:
            s.pos.y += s.speed * dt
            if s.pos.y > self.ctx.world_h:
                s.pos.y = -4
                s.pos.x = random.uniform(0, self.ctx.world_w)

    def _update_wave_and_spawns(self, rs: RunState, dt: float) -> None:
        ctx = self.ctx
        enemies_alive = sum(1 for e in rs.enemies if not e.is_dead)
        boss_alive = rs.boss is not None and not getattr(rs.boss, "is_dead", True)
        requests = rs.wave_manager.update(dt, enemies_alive, boss_alive)
        mods = ctx.config.difficulty_mods()

        for req in requests:
            edef = ENEMY_DEFS[req.enemy_type]
            enemy = Enemy(edef, req.pos, mods, wave_scale=rs.wave_manager.wave_scale())
            rs.enemies.append(enemy)

        if rs.wave_manager.state == WaveState.BOSS_FIGHT and rs.boss is None:
            pos = rs.wave_manager.make_boss_spawn_pos()
            rs.boss = Boss(rs.wave_manager.boss_name, pos, rs.wave_manager.wave_number, mods)
            rs.boss_intro_timer = 2.2
            ctx.sound.play(("lowFrequency_explosion_000", "lowFrequency_explosion_001"), volume=0.7)
            rs.camera.shake(0.6)

        if rs.wave_manager.force_clear_stragglers:
            rs.wave_manager.force_clear_stragglers = False
            for enemy in rs.enemies:
                if not enemy.is_dead:
                    enemy.take_damage(999999)

        if rs.boss_intro_timer > 0:
            rs.boss_intro_timer -= dt

    def _update_enemies(self, rs: RunState, dt: float) -> None:
        ctx = self.ctx
        alive_enemies = [e for e in rs.enemies if not e.is_dead]
        for enemy in list(rs.enemies):
            if enemy.is_dead:
                continue
            bullet = enemy.update(dt, rs.player.pos, ctx.world_w, ctx.world_h, alive_enemies)
            if bullet:
                rs.bullets.add(bullet)
        rs.enemies = [e for e in rs.enemies if not (e.is_dead and self._enemy_death_handled(rs, e))]

    def _enemy_death_handled(self, rs: RunState, enemy: Enemy) -> bool:
        if enemy.death_processed:
            return True
        enemy.death_processed = True
        self._on_enemy_killed(rs, enemy)
        return True

    def _update_boss(self, rs: RunState, dt: float) -> None:
        if rs.boss is None:
            return
        ctx = self.ctx
        boss = rs.boss
        if boss.is_dead:
            if not boss.death_processed:
                boss.death_processed = True
                self._on_boss_killed(rs, boss)
            return

        events = boss.update(dt, rs.player.pos, ctx.world_w, ctx.world_h)
        for b in events.bullets:
            rs.bullets.add(b)
        if events.enraged_this_frame:
            rs.camera.shake(0.5)
            rs.camera.flash(Color.NEON_RED, 120)
            ctx.sound.play("zapThreeToneUp", volume=0.6)
        if events.shockwave_triggered:
            rs.camera.shake(0.7)
            rs.particles.emit_burst_ring(boss.pos, 24, Color.NEON_ORANGE, speed=340)
            ctx.sound.play(("explosionCrunch_000", "explosionCrunch_001"), volume=0.7)
        if events.charge_started:
            ctx.sound.play("phaserUp1", volume=0.5)
        if events.summon_requests:
            mods = ctx.config.difficulty_mods()
            for _ in range(events.summon_requests):
                edge_pos = pygame.Vector2(
                    clamp(boss.pos.x + random.uniform(-200, 200), 40, ctx.world_w - 40),
                    clamp(boss.pos.y + random.uniform(60, 160), 40, ctx.world_h - 40),
                )
                etype = random.choice([EnemyType.SMALL, EnemyType.FAST, EnemyType.SHOOTER])
                rs.enemies.append(Enemy(ENEMY_DEFS[etype], edge_pos, mods, wave_scale=rs.wave_manager.wave_scale() * 0.7))
            ctx.sound.play("phaseJump3", volume=0.5)

    def _nearest_enemy(self, rs: RunState, pos: pygame.Vector2):
        best = None
        best_d = float("inf")
        candidates = [e for e in rs.enemies if not e.is_dead]
        if rs.boss is not None and not rs.boss.is_dead:
            candidates.append(rs.boss)
        for e in candidates:
            d = e.pos.distance_squared_to(pos)
            if d < best_d:
                best_d = d
                best = e
        return best

    # -- collisions --------------------------------------------------
    def _resolve_collisions(self, rs: RunState, dt: float) -> None:
        ctx = self.ctx
        player = rs.player

        results = collision.resolve_player_bullets_vs_enemies(rs.bullets.player_bullets, rs.enemies, rs.boss)
        if results.explosions:
            explosion_hits = collision.apply_explosions(results.explosions, rs.enemies, rs.boss)
            results.enemy_hits.extend(explosion_hits)
            for pos, radius, damage, color in results.explosions:
                rs.particles.emit(pos, 22, color, speed_range=(80, 340), life_range=(0.3, 0.7))
                rs.camera.shake(0.25)
                ctx.sound.play(("explosionCrunch_002", "explosionCrunch_003"), volume=0.5)

        for hit in results.enemy_hits:
            color = hit.color if not hit.crit else Color.NEON_YELLOW
            rs.particles.emit(hit.pos, 6 if not hit.killed else 4, color, speed_range=(40, 160), life_range=(0.2, 0.4), size_range=(1.5, 3.5))
            if ctx.config.damage_numbers_enabled:
                rs.particles.spawn_text(
                    hit.pos, str(int(hit.damage)), color=Color.NEON_YELLOW if hit.crit else Color.WHITE,
                    size=22 if hit.crit else 15, crit=hit.crit,
                )

        rs.bullets.player_bullets = [b for b in rs.bullets.player_bullets if b.lifetime > 0]

        hit_bullets = collision.resolve_enemy_bullets_vs_player(rs.bullets.enemy_bullets, player)
        if hit_bullets:
            rs.camera.shake(0.35)
            rs.camera.flash(Color.NEON_RED, 130)
            ctx.sound.play(("impactMetal_000", "impactMetal_001", "impactMetal_002"), volume=0.6)
        rs.bullets.enemy_bullets = [b for b in rs.bullets.enemy_bullets if b.lifetime > 0]

        exploded = collision.resolve_contact_damage(rs.enemies, rs.boss, player, dt)
        for enemy in exploded:
            rs.particles.emit(enemy.pos, 26, Color.NEON_ORANGE, speed_range=(100, 340), life_range=(0.3, 0.6))
            rs.camera.shake(0.3)
        if exploded:
            ctx.sound.play(("explosionCrunch_000", "explosionCrunch_004"), volume=0.55)

    def _on_enemy_killed(self, rs: RunState, enemy: Enemy) -> None:
        ctx = self.ctx
        player = rs.player
        rs.particles.emit(enemy.pos, 16, enemy.d.color, speed_range=(60, 260), life_range=(0.3, 0.65), size_range=(2, 4.5))
        rs.particles.emit(enemy.pos, 8, Color.WHITE, speed_range=(40, 120), life_range=(0.15, 0.3), size_range=(1, 2))
        ctx.sound.play(("explosionCrunch_001", "explosionCrunch_002", "explosionCrunch_003"), volume=0.4)

        leveled = player.add_xp(enemy.d.xp_reward)
        player.add_coins(enemy.d.coin_reward)
        player.score += enemy.d.score_reward
        if leveled:
            rs.particles.spawn_text(enemy.pos, "LEVEL UP!", color=Color.NEON_YELLOW, size=24, life=1.2)
            ctx.sound.play(("powerUp10", "powerUp11"), volume=0.6)

        if enemy.d.explosive_death:
            radius = 90
            collision.apply_explosions([(enemy.pos, radius, enemy.d.contact_damage * 1.4, Color.NEON_ORANGE)], rs.enemies, rs.boss)
            if collision.circles_hit(enemy.pos, radius, player.pos, player.radius):
                player.take_damage(enemy.d.contact_damage * 1.2)
                rs.camera.shake(0.5)
            rs.particles.emit(enemy.pos, 30, Color.NEON_ORANGE, speed_range=(120, 380), life_range=(0.3, 0.7))

        drop = roll_drop(random.Random(), luck=player.luck)
        if drop is not None:
            rs.powerups.append(PowerUp(enemy.pos, drop))
        elif random.random() < WEAPON_PICKUP_CHANCE:
            locked = [w for w in WEAPON_UNLOCK_ORDER if w not in player.weapons]
            if locked:
                pu = PowerUp(enemy.pos, PowerUpType.HEALTH)
                pu.custom_label = "WPN"
                pu.weapon_reward = random.choice(locked)
                rs.powerups.append(pu)

    def _on_boss_killed(self, rs: RunState, boss) -> None:
        ctx = self.ctx
        player = rs.player
        for _ in range(6):
            offset = pygame.Vector2(random.uniform(-40, 40), random.uniform(-40, 40))
            rs.particles.emit(boss.pos + offset, 40, Color.NEON_ORANGE, speed_range=(120, 420), life_range=(0.4, 1.0))
        rs.particles.emit(boss.pos, 60, Color.WHITE, speed_range=(80, 300), life_range=(0.3, 0.8))
        rs.camera.shake(1.0)
        rs.camera.flash(Color.WHITE, 200)
        ctx.sound.play(("lowFrequency_explosion_000", "lowFrequency_explosion_001"), volume=0.9)

        reward_xp = 220 if not boss.mini else 90
        reward_coins = 150 if not boss.mini else 60
        player.add_xp(reward_xp)
        player.add_coins(reward_coins)
        player.score += 500 if not boss.mini else 200
        player.lives = min(player.lives + 1, 9) if not boss.mini else player.lives
        rs.powerups.append(PowerUp(boss.pos, PowerUpType.HEALTH))
        rs.powerups.append(PowerUp(boss.pos + pygame.Vector2(30, 0), PowerUpType.EXTRA_LIFE))
        rs.wave_manager.notify_boss_defeated()
        rs.boss = None

    def _update_powerups(self, rs: RunState, dt: float) -> None:
        player = rs.player
        magnet = player.status.magnet.active
        rs.powerups = [p for p in rs.powerups if p.update(dt, player.pos, magnet)]

        collected = collision.resolve_pickups(rs.powerups, player)
        for p in collected:
            self._apply_powerup(rs, p)
        rs.powerups = [p for p in rs.powerups if not p.collected]

    def _apply_powerup(self, rs: RunState, p: PowerUp) -> None:
        ctx = self.ctx
        player = rs.player
        kind = p.kind
        d = p.d
        ctx.sound.play(("powerUp1", "powerUp2", "powerUp3", "powerUp4"), volume=0.6)
        rs.particles.spawn_text(p.pos, p.display_label(), color=d.color, size=18, life=1.0)

        weapon_reward = p.weapon_reward
        if weapon_reward is not None:
            player.apply_weapon_pickup(weapon_reward)
            rs.particles.spawn_text(p.pos, f"{WEAPON_DEFS[weapon_reward].name.upper()}!", color=Color.NEON_CYAN, size=20, life=1.3)
            return

        if kind == PowerUpType.HEALTH:
            player.heal(player.max_health * 0.35)
        elif kind == PowerUpType.SHIELD_BOOST:
            player.add_shield(40)
        elif kind == PowerUpType.RAPID_FIRE:
            player.status.rapid_fire.start(d.duration)
        elif kind == PowerUpType.DOUBLE_DAMAGE:
            player.status.double_damage.start(d.duration)
        elif kind == PowerUpType.TRIPLE_SHOT:
            player.status.triple_shot.start(d.duration)
        elif kind == PowerUpType.HOMING:
            player.status.homing.start(d.duration)
        elif kind == PowerUpType.SPEED_BOOST:
            player.status.speed_boost.start(d.duration)
        elif kind == PowerUpType.SLOW_MOTION:
            player.status.slow_motion.start(d.duration)
        elif kind == PowerUpType.MAGNET:
            player.status.magnet.start(d.duration)
        elif kind == PowerUpType.FREEZE:
            for e in rs.enemies:
                if not e.is_dead:
                    e.freeze(d.duration)
            rs.camera.flash(Color.NEON_BLUE, 100)
        elif kind == PowerUpType.BOMB:
            targets = [e for e in rs.enemies if not e.is_dead]
            for e in targets:
                e.take_damage(9999)
            if rs.boss is not None and not rs.boss.is_dead:
                rs.boss.take_damage(rs.boss.max_health * 0.25)
            rs.camera.shake(0.8)
            rs.camera.flash(Color.WHITE, 220)
            ctx.sound.play(("lowFrequency_explosion_000", "lowFrequency_explosion_001"), volume=0.8)
        elif kind == PowerUpType.INVINCIBILITY:
            player.status.invincibility.start(d.duration)
        elif kind == PowerUpType.EXTRA_LIFE:
            player.lives += 1
        elif kind == PowerUpType.COIN_MULTIPLIER:
            player.status.coin_boost.start(d.duration)
        elif kind == PowerUpType.REGEN:
            player.status.regen.start(d.duration)

    def _check_wave_transitions(self, rs: RunState) -> None:
        if rs.wave_manager.state == WaveState.INTERMISSION and not rs.shop_shown_this_intermission:
            rs.shop_shown_this_intermission = True
            from scenes.shop import ShopScene
            self.manager.push(ShopScene(self.ctx))
        elif rs.wave_manager.state != WaveState.INTERMISSION:
            rs.shop_shown_this_intermission = False

    def _handle_game_over(self, rs: RunState) -> None:
        rs.game_over_processed = True
        save = self.ctx.save_data
        save.total_coins += rs.player.coins
        save.high_score = max(save.high_score, rs.player.score)
        save.waves_survived_best = max(save.waves_survived_best, rs.wave_manager.wave_number)
        save_game(save)
        from scenes.game_over import GameOverScene
        self.manager.switch(GameOverScene(self.ctx))

    # -- draw -----------------------------------------------------------
    def draw(self, surface: pygame.Surface) -> None:
        ctx = self.ctx
        rs: RunState = ctx.run_state
        if rs is None:
            return
        offset = rs.camera.offset

        self._draw_background(surface, rs, offset)
        self._draw_powerups(surface, rs, offset)
        self._draw_enemies(surface, rs, offset)
        if rs.boss is not None and not rs.boss.is_dead:
            self._draw_boss(surface, rs.boss, offset)
        self._draw_bullets(surface, rs, offset)
        if not rs.player.is_dead:
            self._draw_player(surface, rs.player, offset)
        rs.particles.draw(surface, offset)
        rs.particles.draw_texts(surface, offset)
        rs.camera.draw_flash(surface)
        self._draw_hud(surface, rs)
        if rs.boss_intro_timer > 0 and rs.boss is not None:
            self._draw_boss_intro(surface, rs)

    def _draw_background(self, surface: pygame.Surface, rs: RunState, offset) -> None:
        surface.fill(Color.BG_TOP)
        for s in rs.stars:
            c = (s.brightness, s.brightness, min(255, s.brightness + 20))
            pygame.draw.circle(surface, c, (int(s.pos.x + offset.x * 0.3), int(s.pos.y + offset.y * 0.3)), max(1, int(s.size)))

    def _draw_player(self, surface: pygame.Surface, player: Player, offset) -> None:
        if player.iframe_timer.active and int(player.iframe_timer.time_left * 18) % 2 == 0:
            return  # blink while invincible
        size = 58
        img = assets.get_image("spaceShips_001", (size, size))
        rotated = pygame.transform.rotate(img, player.angle + 90)
        rect = rotated.get_rect(center=(player.pos.x + offset.x, player.pos.y + offset.y))

        if player.status.invincibility.active or player.shield > 0:
            glow_color = Color.NEON_YELLOW if player.status.invincibility.active else Color.SHIELD
            glow = pygame.Surface((size + 40, size + 40), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*glow_color[:3], 70), glow.get_rect().center, size // 2 + 16, 4)
            surface.blit(glow, glow.get_rect(center=rect.center))

        if player.is_moving:
            flame_size = int(20 + 6 * math.sin(player.thruster_pulse))
            flame_img = assets.get_image("spaceEffects_003", (flame_size, int(flame_size * 1.6)))
            back_dir = -player.facing_vector()
            flame_pos = player.pos + back_dir * (player.radius * 0.9) + offset
            flame_angle = player.angle + 90
            flame_rot = pygame.transform.rotate(flame_img, flame_angle + 180)
            surface.blit(flame_rot, flame_rot.get_rect(center=flame_pos))

        surface.blit(rotated, rect)

    def _draw_enemies(self, surface: pygame.Surface, rs: RunState, offset) -> None:
        for enemy in rs.enemies:
            if enemy.is_dead:
                continue
            scale = 1.0
            if enemy.spawn_anim.active:
                scale = 0.3 + 0.7 * (1 - enemy.spawn_anim.remaining_ratio)
            size = max(8, int(enemy.radius * 2.3 * scale))
            img = assets.get_image(enemy.d.sprite_key, (size, size))
            if enemy.hit_flash.active:
                img = self._flash_white(img)
            rotated = pygame.transform.rotate(img, enemy.angle + 90 if enemy.d.rotates else enemy.angle)
            rect = rotated.get_rect(center=(enemy.pos.x + offset.x, enemy.pos.y + offset.y))
            surface.blit(rotated, rect)

            if enemy.shield_active:
                sh = pygame.Surface((size + 20, size + 20), pygame.SRCALPHA)
                pygame.draw.circle(sh, (*Color.NEON_BLUE, 90), sh.get_rect().center, size // 2 + 8, 3)
                surface.blit(sh, sh.get_rect(center=rect.center))

            if enemy.frozen_timer.active:
                fz = pygame.Surface((size, size), pygame.SRCALPHA)
                pygame.draw.rect(fz, (150, 220, 255, 90), fz.get_rect(), border_radius=8)
                surface.blit(fz, rect.topleft)

            if enemy.health_ratio() < 1.0 or enemy.max_health > 40:
                bar_rect = pygame.Rect(0, 0, size, 5)
                bar_rect.midbottom = (rect.centerx, rect.top - 6)
                draw_bar(surface, bar_rect, enemy.health_ratio(), Color.HEALTH if enemy.health_ratio() > 0.3 else Color.HEALTH_LOW, radius=2)

    def _draw_boss(self, surface: pygame.Surface, boss, offset) -> None:
        scale = 1.0
        if boss.spawn_anim.active:
            scale = 0.3 + 0.7 * (1 - boss.spawn_anim.remaining_ratio)
        size = int(boss.radius * 2.4 * scale)
        img = assets.get_image(boss.sprite_key, (size, size))
        if boss.hit_flash.active:
            img = self._flash_white(img)
        rotated = pygame.transform.rotate(img, boss.angle + 90)
        rect = rotated.get_rect(center=(boss.pos.x + offset.x, boss.pos.y + offset.y))

        if boss.enraged:
            glow = pygame.Surface((size + 50, size + 50), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*Color.NEON_RED, 60), glow.get_rect().center, size // 2 + 20, 5)
            surface.blit(glow, glow.get_rect(center=rect.center))

        surface.blit(rotated, rect)

        if boss.shield_active:
            sh = pygame.Surface((size + 30, size + 30), pygame.SRCALPHA)
            pygame.draw.circle(sh, (*Color.NEON_BLUE, 100), sh.get_rect().center, size // 2 + 14, 4)
            surface.blit(sh, sh.get_rect(center=rect.center))

    @staticmethod
    def _flash_white(img: pygame.Surface) -> pygame.Surface:
        flashed = img.copy()
        flashed.fill((255, 255, 255, 0), special_flags=pygame.BLEND_RGBA_ADD)
        return flashed

    def _draw_bullets(self, surface: pygame.Surface, rs: RunState, offset) -> None:
        for b in rs.bullets.player_bullets:
            self._draw_bullet(surface, b, offset)
        for b in rs.bullets.enemy_bullets:
            self._draw_bullet(surface, b, offset)

    def _draw_bullet(self, surface: pygame.Surface, b, offset) -> None:
        img = assets.get_image(b.sprite_key or "spaceMissiles_017", b.sprite_size)
        rotated = pygame.transform.rotate(img, b.angle)
        rect = rotated.get_rect(center=(b.pos.x + offset.x, b.pos.y + offset.y))
        if b.glow:
            glow = pygame.Surface((rect.width + 16, rect.height + 16), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*b.color[:3], 60), glow.get_rect().center, max(rect.width, rect.height) // 2 + 4)
            surface.blit(glow, glow.get_rect(center=rect.center), special_flags=pygame.BLEND_RGBA_ADD)
        surface.blit(rotated, rect)

    def _draw_powerups(self, surface: pygame.Surface, rs: RunState, offset) -> None:
        for p in rs.powerups:
            bob = p.bob_offset()
            pos = (p.pos.x + offset.x, p.pos.y + offset.y + bob)
            pulse = 1.0 + 0.15 * math.sin(p.bob_phase * 1.6)
            r = int(p.radius * pulse)
            glow = pygame.Surface((r * 4, r * 4), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*p.d.color[:3], 70), glow.get_rect().center, r * 2)
            surface.blit(glow, glow.get_rect(center=pos), special_flags=pygame.BLEND_RGBA_ADD)
            pygame.draw.circle(surface, p.d.color, pos, r)
            pygame.draw.circle(surface, Color.WHITE, pos, r, 2)
            draw_text(surface, p.display_label(), pos, size=11, color=Color.BLACK, align="center", shadow=False)

            if p.lifetime.remaining_ratio < 0.3:
                ring_rect = pygame.Rect(0, 0, r * 2 + 8, r * 2 + 8)
                ring_rect.center = pos
                pygame.draw.arc(surface, Color.WHITE, ring_rect, 0, math.tau * p.lifetime.remaining_ratio, 2)

    def _draw_boss_intro(self, surface: pygame.Surface, rs: RunState) -> None:
        w = self.ctx.world_w
        alpha = int(clamp(rs.boss_intro_timer / 2.2, 0, 1) * 255)
        draw_text(surface, rs.boss.name.upper(), (w / 2, 120), size=46, color=Color.NEON_RED, align="center", alpha=alpha)
        draw_text(surface, "WARNING: BOSS APPROACHING", (w / 2, 168), size=20, color=Color.WHITE, align="center", alpha=alpha)

    # -- HUD --------------------------------------------------------------
    def _draw_hud(self, surface: pygame.Surface, rs: RunState) -> None:
        ctx = self.ctx
        player = rs.player
        w, h = ctx.world_w, ctx.world_h

        # top-left: health / shield / xp
        panel = pygame.Rect(16, 14, 300, 92)
        draw_panel(surface, panel)
        draw_bar(surface, pygame.Rect(panel.x + 14, panel.y + 12, panel.width - 28, 16),
                  player.health / player.max_health, Color.HEALTH if player.health > player.max_health * 0.3 else Color.HEALTH_LOW, glow=True)
        draw_text(surface, f"HP {int(player.health)}/{int(player.max_health)}", (panel.x + 14, panel.y + 10), size=12, color=Color.WHITE)

        shield_ratio = (player.shield / player.max_shield) if player.max_shield else 0
        draw_bar(surface, pygame.Rect(panel.x + 14, panel.y + 36, panel.width - 28, 10), shield_ratio, Color.SHIELD)
        draw_text(surface, f"SHIELD {int(player.shield)}/{int(player.max_shield)}", (panel.x + 14, panel.y + 34), size=10, color=Color.UI_DIM)

        xp_ratio = player.xp / player.xp_to_next if player.xp_to_next else 0
        draw_bar(surface, pygame.Rect(panel.x + 14, panel.y + 58, panel.width - 28, 8), xp_ratio, Color.XP)
        draw_text(surface, f"LV {player.level}", (panel.x + 14, panel.y + 68), size=12, color=Color.NEON_PURPLE)
        draw_text(surface, "x" + str(player.lives), (panel.x + panel.width - 14, panel.y + 68), size=14, color=Color.NEON_MAGENTA, align="topright")

        # top-right: coins / score / wave
        panel2 = pygame.Rect(w - 260, 14, 244, 92)
        draw_panel(surface, panel2)
        draw_text(surface, f"SCORE {format_number(player.score)}", (panel2.right - 14, panel2.y + 10), size=14, align="topright")
        draw_text(surface, f"COINS {player.coins}", (panel2.right - 14, panel2.y + 32), size=14, color=Color.COIN, align="topright")
        wave_label = f"WAVE {rs.wave_manager.wave_number}"
        if rs.wave_manager.state == WaveState.INTERMISSION:
            wave_label += f"  (next in {rs.wave_manager.intermission_timer.time_left:.1f}s)"
        draw_text(surface, wave_label, (panel2.right - 14, panel2.y + 54), size=13, color=Color.NEON_CYAN, align="topright")
        if not rs.wave_manager.is_boss_wave:
            draw_text(surface, f"Boss in {rs.wave_manager.next_boss_in} waves", (panel2.right - 14, panel2.y + 72), size=11, color=Color.UI_DIM, align="topright")

        # bottom-left: weapon
        wpanel = pygame.Rect(16, h - 76, 260, 60)
        draw_panel(surface, wpanel)
        wstats = player.weapon.stats
        draw_text(surface, wstats.name.upper(), (wpanel.x + 14, wpanel.y + 10), size=15, color=wstats.color)
        draw_text(surface, f"LV {player.weapon.level}   [Q/E] switch", (wpanel.x + 14, wpanel.y + 32), size=11, color=Color.UI_DIM)

        # power-up timers, bottom-right
        self._draw_active_effects(surface, rs)

        # boss health bar top-center
        if rs.boss is not None and not rs.boss.is_dead:
            bar_w = min(700, w - 320)
            bar_rect = pygame.Rect(0, 0, bar_w, 22)
            bar_rect.midtop = (w / 2, 16)
            draw_panel(surface, bar_rect.inflate(16, 16), alpha=180)
            draw_bar(surface, bar_rect, rs.boss.health_ratio(), Color.NEON_RED, glow=True)
            draw_text(surface, rs.boss.name.upper(), (w / 2, bar_rect.bottom + 10), size=14, color=Color.WHITE, align="midtop")

        if ctx.config.show_fps:
            fps = int(ctx.clock.get_fps())
            draw_text(surface, f"{fps} FPS", (w - 14, h - 26), size=13, color=Color.UI_DIM, align="topright")

    def _draw_active_effects(self, surface: pygame.Surface, rs: RunState) -> None:
        player = rs.player
        active = []
        for name in player.status.__dataclass_fields__:
            timer = getattr(player.status, name)
            if timer.active and timer.duration > 0:
                active.append((name, timer))
        if not active:
            return
        w = self.ctx.world_w
        x = w - 16
        y = 116
        for name, timer in active:
            box = pygame.Rect(0, 0, 150, 22)
            box.topright = (x, y)
            draw_panel(surface, box, alpha=170, radius=6)
            ratio = timer.remaining_ratio
            draw_bar(surface, box.inflate(-8, -14), ratio, Color.NEON_CYAN, radius=3)
            label = name.replace("_", " ").upper()
            draw_text(surface, label, box.center, size=10, align="center")
            y += 26
