[app]
title = Triangle Assault
package.name = triangleassault
package.domain = org.triangleassault

source.dir = .
source.include_exts = py,png,jpg,jpeg,ogg,wav,ttf,otf,json,md

version = 1.0

# pygame-ce, not pygame -- python-for-android's "pygame" recipe builds
# against SDL2 and is compatible with pygame-ce's API.
requirements = python3,pygame-ce

orientation = landscape
fullscreen = 1

icon.filename = %(source.dir)s/assets/images/ships/spaceShips_001.png

android.archs = arm64-v8a, armeabi-v7a
android.api = 33
android.minapi = 21
android.permissions = VIBRATE

[buildozer]
log_level = 2
warn_on_root = 1
